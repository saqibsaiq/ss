import "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as formatMonth, t as cn } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as FileDown, p as Copy, r as Printer } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[background-color,color,box-shadow,opacity,transform] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-border hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground shadow-border hover:bg-accent",
			outline: "bg-transparent text-foreground shadow-border hover:bg-accent",
			ghost: "text-foreground hover:bg-accent",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90",
			link: "text-foreground underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function DropdownMenu(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2, { ...props });
}
function DropdownMenuTrigger(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, { ...props });
}
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-50 min-w-44 overflow-hidden rounded-lg bg-popover p-1 text-popover-foreground shadow-border-hover data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props
	}) });
}
function DropdownMenuItem({ className, inset, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-md px-2 py-2 text-sm outline-none select-none focus:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", inset && "pl-8", className),
		...props
	});
}
function composeResume(profile, tailored) {
	if (!tailored) return profile;
	return {
		...profile,
		headline: tailored.headline,
		summary: tailored.summary,
		skills: tailored.skills,
		experience: tailored.experience,
		education: tailored.education.length ? tailored.education : profile.education,
		projects: tailored.projects
	};
}
function contactLine(resume) {
	return [
		resume.location,
		resume.email,
		resume.phone,
		resume.website
	].filter(Boolean).join("  ·  ");
}
function resumeToPlainText(resume) {
	const lines = [];
	lines.push(resume.fullName);
	if (resume.headline) lines.push(resume.headline);
	const contact = contactLine(resume);
	if (contact) lines.push(contact);
	lines.push("");
	if (resume.summary) {
		lines.push("SUMMARY");
		lines.push(resume.summary);
		lines.push("");
	}
	if (resume.skills?.length) {
		lines.push("SKILLS");
		lines.push(resume.skills.join(" · "));
		lines.push("");
	}
	if (resume.experience?.length) {
		lines.push("EXPERIENCE");
		for (const job of resume.experience) {
			lines.push(`${job.title} — ${job.company}  (${formatMonth(job.start)} – ${formatMonth(job.end)})`);
			if (job.location) lines.push(job.location);
			for (const b of job.bullets.filter(Boolean)) lines.push(`• ${b}`);
			lines.push("");
		}
	}
	if (resume.projects?.length) {
		lines.push("PROJECTS");
		for (const p of resume.projects) {
			lines.push(p.url ? `${p.name} — ${p.url}` : p.name);
			for (const b of p.bullets.filter(Boolean)) lines.push(`• ${b}`);
			lines.push("");
		}
	}
	if (resume.education?.length) {
		lines.push("EDUCATION");
		for (const e of resume.education) {
			lines.push(`${e.degree} — ${e.school}, ${e.year}`);
			if (e.detail) lines.push(e.detail);
		}
	}
	return lines.join("\n").trim();
}
function resumeToMarkdown(resume) {
	const lines = [];
	lines.push(`# ${resume.fullName}`);
	if (resume.headline) lines.push(`*${resume.headline}*`);
	const contact = contactLine(resume);
	if (contact) lines.push(contact);
	lines.push("");
	if (resume.summary) {
		lines.push("## Summary");
		lines.push(resume.summary);
		lines.push("");
	}
	if (resume.skills?.length) {
		lines.push("## Skills");
		lines.push(resume.skills.join(" · "));
		lines.push("");
	}
	if (resume.experience?.length) {
		lines.push("## Experience");
		for (const job of resume.experience) {
			lines.push(`### ${job.title} — ${job.company}`);
			lines.push(`*${formatMonth(job.start)} – ${formatMonth(job.end)}${job.location ? ` · ${job.location}` : ""}*`);
			for (const b of job.bullets.filter(Boolean)) lines.push(`- ${b}`);
			lines.push("");
		}
	}
	if (resume.projects?.length) {
		lines.push("## Projects");
		for (const p of resume.projects) {
			lines.push(`### ${p.name}`);
			if (p.url) lines.push(`*${p.url}*`);
			for (const b of p.bullets.filter(Boolean)) lines.push(`- ${b}`);
			lines.push("");
		}
	}
	if (resume.education?.length) {
		lines.push("## Education");
		for (const e of resume.education) {
			lines.push(`**${e.degree}**, ${e.school} (${e.year})`);
			if (e.detail) lines.push(e.detail);
		}
	}
	return lines.join("\n").trim();
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		return false;
	}
}
function ExportMenu({ resume }) {
	async function copy(kind) {
		const ok = await copyText(kind === "md" ? resumeToMarkdown(resume) : resumeToPlainText(resume));
		toast(ok ? "Copied to clipboard" : "Could not copy");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, {}), "Export"]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => void copy("text"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copy as text"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => void copy("md"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copy as Markdown"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onSelect: () => window.print(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print / save PDF"]
			})
		]
	})] });
}
function ResumePaper({ resume, className, compact = false }) {
	const contact = contactLine(resume);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("print-paper bg-paper text-ink shadow-paper", compact ? "rounded-lg px-6 py-7" : "rounded-lg px-8 py-10 sm:px-11 sm:py-12", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: cn("font-display font-medium tracking-tight text-balance", compact ? "text-2xl" : "text-3xl sm:text-4xl"),
						children: resume.fullName || "Your name"
					}),
					resume.headline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-2 text-muted-foreground", compact ? "text-sm" : "text-sm sm:text-base"),
						children: resume.headline
					}) : null,
					contact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs tracking-wide text-muted-foreground",
						children: contact
					}) : null
				]
			}),
			resume.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Summary",
				compact,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("leading-relaxed", compact ? "text-sm" : "text-sm sm:text-[0.9375rem]"),
					children: resume.summary
				})
			}) : null,
			resume.skills.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Skills",
				compact,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed",
					children: resume.skills.join("  ·  ")
				})
			}) : null,
			resume.experience.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Experience",
				compact,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-5",
					children: resume.experience.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-sm font-semibold",
								children: [job.title, job.company ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-normal text-muted-foreground",
									children: [
										" ",
										"— ",
										job.company
									]
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums text-muted-foreground",
								children: [
									formatMonth(job.start),
									job.start ? " – " : "",
									formatMonth(job.end) || "Present"
								]
							})]
						}),
						job.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-muted-foreground",
							children: job.location
						}) : null,
						job.bullets.filter(Boolean).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 flex flex-col gap-1.5",
							children: job.bullets.filter(Boolean).map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "relative pl-3.5 text-sm leading-relaxed before:absolute before:left-0 before:top-2 before:size-1 before:rounded-full before:bg-foreground/50",
								children: b
							}, `${job.id}-${i}`))
						}) : null
					] }, job.id))
				})
			}) : null,
			resume.projects.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Projects",
				compact,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-4",
					children: resume.projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-sm font-semibold",
						children: [p.name, p.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-normal text-muted-foreground",
							children: p.url
						}) : null]
					}), p.bullets.filter(Boolean).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1.5 flex flex-col gap-1",
						children: p.bullets.filter(Boolean).map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "relative pl-3.5 text-sm leading-relaxed before:absolute before:left-0 before:top-2 before:size-1 before:rounded-full before:bg-foreground/50",
							children: b
						}, `${p.id}-${i}`))
					}) : null] }, p.id))
				})
			}) : null,
			resume.education.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Education",
				compact,
				children: resume.education.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-baseline justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: e.degree
							}),
							e.school ? ` — ${e.school}` : "",
							e.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [" · ", e.detail]
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tabular-nums text-muted-foreground",
						children: e.year
					})]
				}, e.id))
			}) : null
		]
	});
}
function Section({ title, children, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn(compact ? "mt-6" : "mt-8"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-2.5 border-b border-foreground/12 pb-1 font-sans text-xs font-semibold tracking-widest text-muted-foreground uppercase",
			children: title
		}), children]
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md bg-card px-3 text-sm text-foreground shadow-border transition-[box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		className: cn("text-sm font-medium text-foreground/80", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-32 w-full rounded-lg bg-card px-3 py-3 text-sm text-foreground shadow-border transition-[box-shadow] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
//#endregion
export { ResumePaper as a, Label as i, ExportMenu as n, Textarea as o, Input as r, composeResume as s, Button as t };
