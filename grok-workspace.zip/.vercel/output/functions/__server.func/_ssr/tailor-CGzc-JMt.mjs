import { i as uid } from "./utils-S0PEXG6m.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tailor-CGzc-JMt.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SCHEMA_HINT = `{
  "headline": "string",
  "summary": "string, 3-4 sentences",
  "skills": ["reordered, JD-relevant first, only from the original list"],
  "experience": [{ "id": "original id", "bullets": ["rewritten, truthful"], "keep": true }],
  "projects": [{ "id": "original id", "bullets": ["rewritten"], "keep": true }],
  "matchScore": 0-100,
  "keywordsHit": ["terms present in both JD and resume"],
  "keywordsMissed": ["important JD terms the resume cannot honestly claim"],
  "changes": ["what you changed and why"],
  "coverNote": "3-5 sentence note the candidate could paste into the application"
}`;
function extractJson(text) {
	const raw = (text.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? text).trim();
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start === -1 || end === -1) throw new Error("No JSON object in model output");
	return JSON.parse(raw.slice(start, end + 1));
}
function asStringArray(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((v) => typeof v === "string").map((v) => v.trim()).filter(Boolean);
}
var tailorResume_createServerFn_handler = createServerRpc({
	id: "d4e09d3ffc43b223726143786dc582610d6a98b2b738f179f502d859a8386215",
	name: "tailorResume",
	filename: "src/lib/tailor.ts"
}, (opts) => tailorResume.__executeServer(opts));
var tailorResume = createServerFn({ method: "POST" }).validator((input) => input).handler(tailorResume_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment."
	};
	const jd = data.jobDescription.slice(0, 8e3);
	const compactProfile = {
		fullName: data.profile.fullName,
		headline: data.profile.headline,
		summary: data.profile.summary,
		skills: data.profile.skills,
		experience: data.profile.experience.map((e) => ({
			id: e.id,
			company: e.company,
			title: e.title,
			location: e.location,
			start: e.start,
			end: e.end,
			bullets: e.bullets
		})),
		education: data.profile.education,
		projects: data.profile.projects.map((p) => ({
			id: p.id,
			name: p.name,
			url: p.url,
			bullets: p.bullets
		}))
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: 2800,
			messages: [{
				role: "system",
				content: "You are a precise resume strategist. Tailor a master resume for one job. Never invent employers, titles, dates, metrics, or skills the candidate did not provide. You may rewrite bullets, drop weaker ones, reorder, and change emphasis. Return JSON only."
			}, {
				role: "user",
				content: `Company: ${data.company || "(unknown)"}
Role: ${data.role || "(unknown)"}

JOB DESCRIPTION:
${jd}

MASTER RESUME:
${JSON.stringify(compactProfile)}

Return a single JSON object matching this shape:
${SCHEMA_HINT}

Keep experience and project ids identical to the master resume. Omit an experience/project only by setting keep:false. Skills must be a subset of the original skills (you may reorder). matchScore reflects honest overlap, not optimism.`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `The tailor could not reach the model (${res.status}).`
	};
	const text = (await res.json()).choices?.[0]?.message?.content ?? "";
	if (!text) return {
		ok: false,
		error: "The model returned an empty reply."
	};
	try {
		const parsed = extractJson(text);
		const experienceById = new Map(data.profile.experience.map((e) => [e.id, e]));
		const projectById = new Map(data.profile.projects.map((p) => [p.id, p]));
		const experience = (Array.isArray(parsed.experience) ? parsed.experience : []).map((item) => {
			if (!item || typeof item !== "object") return null;
			const rec = item;
			const id = typeof rec.id === "string" ? rec.id : "";
			const original = experienceById.get(id);
			if (!original || rec.keep === false) return null;
			const bullets = asStringArray(rec.bullets);
			return {
				...original,
				bullets: bullets.length ? bullets : original.bullets
			};
		}).filter((e) => e !== null);
		const projects = (Array.isArray(parsed.projects) ? parsed.projects : []).map((item) => {
			if (!item || typeof item !== "object") return null;
			const rec = item;
			const id = typeof rec.id === "string" ? rec.id : "";
			const original = projectById.get(id);
			if (!original || rec.keep === false) return null;
			const bullets = asStringArray(rec.bullets);
			return {
				...original,
				bullets: bullets.length ? bullets : original.bullets
			};
		}).filter((p) => p !== null);
		const allowedSkills = new Set(data.profile.skills.map((s) => s.toLowerCase()));
		const skills = asStringArray(parsed.skills).filter((s) => allowedSkills.has(s.toLowerCase()));
		const scoreRaw = parsed.matchScore;
		const matchScore = typeof scoreRaw === "number" && Number.isFinite(scoreRaw) ? Math.max(0, Math.min(100, Math.round(scoreRaw))) : null;
		return {
			ok: true,
			resume: {
				id: uid(),
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				headline: typeof parsed.headline === "string" && parsed.headline.trim() ? parsed.headline.trim() : data.profile.headline,
				summary: typeof parsed.summary === "string" && parsed.summary.trim() ? parsed.summary.trim() : data.profile.summary,
				skills: skills.length ? skills : data.profile.skills,
				experience: experience.length ? experience : data.profile.experience,
				education: data.profile.education,
				projects: projects.length ? projects : data.profile.projects,
				matchScore,
				keywordsHit: asStringArray(parsed.keywordsHit).slice(0, 12),
				keywordsMissed: asStringArray(parsed.keywordsMissed).slice(0, 8),
				changes: asStringArray(parsed.changes).slice(0, 8),
				coverNote: typeof parsed.coverNote === "string" ? parsed.coverNote.trim() : ""
			}
		};
	} catch {
		return {
			ok: false,
			error: "Could not read the tailored resume. Try again."
		};
	}
});
//#endregion
export { tailorResume_createServerFn_handler };
