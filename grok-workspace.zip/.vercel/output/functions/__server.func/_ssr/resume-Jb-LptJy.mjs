import { i as __toESM } from "../_runtime.mjs";
import { i as uid } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Plus, n as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as useVellum } from "./router-CD1JqM-p.mjs";
import { a as ResumePaper, i as Label, n as ExportMenu, o as Textarea, r as Input, t as Button } from "./textarea-CFxZJC2O.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resume-Jb-LptJy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MasterResumePage() {
	const profile = useVellum((s) => s.profile);
	const setProfile = useVellum((s) => s.setProfile);
	const resetWorkspace = useVellum((s) => s.resetWorkspace);
	const importSnapshot = useVellum((s) => s.importSnapshot);
	const fileRef = (0, import_react.useRef)(null);
	function patch(partial) {
		setProfile({
			...profile,
			...partial
		});
	}
	function exportWorkspace() {
		const { applications, resumes } = useVellum.getState();
		const blob = new Blob([JSON.stringify({
			profile,
			applications,
			resumes
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "vellum-workspace.json";
		a.click();
		URL.revokeObjectURL(url);
	}
	function onImport(file) {
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const parsed = JSON.parse(String(reader.result));
				if (!parsed.profile?.fullName) throw new Error("Invalid file");
				importSnapshot({
					profile: parsed.profile,
					applications: Array.isArray(parsed.applications) ? parsed.applications : [],
					resumes: parsed.resumes && typeof parsed.resumes === "object" ? parsed.resumes : {}
				});
				toast("Workspace imported");
			} catch {
				toast("Could not read that file");
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
							children: "Source of truth"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-display text-3xl tracking-tight",
							children: "Master resume"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-md text-sm text-muted-foreground",
							children: "Edit once. Every tailored version starts from here — we never invent facts."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, { resume: profile })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Full name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.fullName,
								onChange: (e) => patch({ fullName: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Headline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.headline,
								onChange: (e) => patch({ headline: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Email",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: profile.email,
										onChange: (e) => patch({ email: e.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Phone",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: profile.phone,
										onChange: (e) => patch({ phone: e.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Location",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: profile.location,
										onChange: (e) => patch({ location: e.target.value })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Website",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: profile.website,
										onChange: (e) => patch({ website: e.target.value })
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Summary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 5,
								value: profile.summary,
								onChange: (e) => patch({ summary: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Skills",
							hint: "Comma separated",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: profile.skills.join(", "),
								onChange: (e) => patch({ skills: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Experience"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => patch({ experience: [{
								id: uid(),
								company: "",
								title: "",
								location: "",
								start: "",
								end: "",
								bullets: [""]
							}, ...profile.experience] }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add role"]
						})]
					}), profile.experience.map((job, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceEditor, {
						job,
						onChange: (next) => {
							const experience = profile.experience.slice();
							experience[index] = next;
							patch({ experience });
						},
						onRemove: () => patch({ experience: profile.experience.filter((e) => e.id !== job.id) })
					}, job.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Projects"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => patch({ projects: [{
								id: uid(),
								name: "",
								url: "",
								bullets: [""]
							}, ...profile.projects] }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add project"]
						})]
					}), profile.projects.map((p, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectEditor, {
						project: p,
						onChange: (next) => {
							const projects = profile.projects.slice();
							projects[index] = next;
							patch({ projects });
						},
						onRemove: () => patch({ projects: profile.projects.filter((x) => x.id !== p.id) })
					}, p.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl",
							children: "Education"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => patch({ education: [...profile.education, {
								id: uid(),
								school: "",
								degree: "",
								year: "",
								detail: ""
							}] }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add"]
						})]
					}), profile.education.map((e, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationEditor, {
						edu: e,
						onChange: (next) => {
							const education = profile.education.slice();
							education[index] = next;
							patch({ education });
						},
						onRemove: () => patch({ education: profile.education.filter((x) => x.id !== e.id) })
					}, e.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-wrap gap-2 border-t border-border pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: exportWorkspace,
							children: "Download workspace"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => fileRef.current?.click(),
							children: "Import workspace"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: (e) => onImport(e.target.files?.[0])
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => {
								resetWorkspace();
								toast("Sample workspace restored");
							},
							children: "Restore sample"
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "no-print hidden lg:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs font-medium tracking-widest text-muted-foreground uppercase",
					children: "Preview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResumePaper, { resume: profile })]
			})
		})]
	});
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: hint
			}) : null]
		}), children]
	});
}
function ExperienceEditor({ job, onChange, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					onClick: onRemove,
					"aria-label": "Remove role",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Title",
						value: job.title,
						onChange: (e) => onChange({
							...job,
							title: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Company",
						value: job.company,
						onChange: (e) => onChange({
							...job,
							company: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Location",
						value: job.location,
						onChange: (e) => onChange({
							...job,
							location: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Start (YYYY-MM)",
							value: job.start,
							onChange: (e) => onChange({
								...job,
								start: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "End or Present",
							value: job.end,
							onChange: (e) => onChange({
								...job,
								end: e.target.value
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				className: "mt-3",
				rows: 5,
				placeholder: "One achievement per line",
				value: job.bullets.join("\n"),
				onChange: (e) => onChange({
					...job,
					bullets: e.target.value.split("\n")
				})
			})
		]
	});
}
function ProjectEditor({ project, onChange, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					onClick: onRemove,
					"aria-label": "Remove project",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Name",
					value: project.name,
					onChange: (e) => onChange({
						...project,
						name: e.target.value
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "URL",
					value: project.url,
					onChange: (e) => onChange({
						...project,
						url: e.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				className: "mt-3",
				rows: 3,
				placeholder: "One line per bullet",
				value: project.bullets.join("\n"),
				onChange: (e) => onChange({
					...project,
					bullets: e.target.value.split("\n")
				})
			})
		]
	});
}
function EducationEditor({ edu, onChange, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-xl bg-card p-4 shadow-border sm:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:col-span-11 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Degree",
					value: edu.degree,
					onChange: (e) => onChange({
						...edu,
						degree: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "School",
					value: edu.school,
					onChange: (e) => onChange({
						...edu,
						school: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Year",
					value: edu.year,
					onChange: (e) => onChange({
						...edu,
						year: e.target.value
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Detail",
					value: edu.detail,
					onChange: (e) => onChange({
						...edu,
						detail: e.target.value
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon-sm",
			className: "sm:col-span-1",
			onClick: onRemove,
			"aria-label": "Remove education",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
		})]
	});
}
//#endregion
export { MasterResumePage as component };
