import { i as __toESM } from "../_runtime.mjs";
import { i as uid, t as cn } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as PenLine, c as ListFilter, s as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as useVellum, r as createApplicationDraft } from "./router-CD1JqM-p.mjs";
import { a as ResumePaper, i as Label, n as ExportMenu, o as Textarea, r as Input, s as composeResume, t as Button } from "./textarea-CFxZJC2O.mjs";
import { t as tailorResume } from "./tailor-BUF36r6V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apply-BHpeNWaa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STOP = new Set("a an the and or of to for in on with without from by as at is are be this that those these we you your our their they it its into over under than then also will can should must have has had using use used about across after before between among per via such other more most any all not no yes".split(" "));
function tokens(text) {
	return text.toLowerCase().replace(/[^a-z0-9+.#\s-]/g, " ").split(/[\s,/|]+/).map((t) => t.trim()).filter((t) => t.length > 2 && !STOP.has(t));
}
function phrases(text) {
	const found = /* @__PURE__ */ new Set();
	for (const m of text.match(/\b(?:TypeScript|JavaScript|React|Node\.?js|GraphQL|Postgres(?:ql)?|PostgreSQL|AWS|GCP|Azure|Kubernetes|Docker|Python|Go|Rust|Java|Kotlin|Swift|Next\.js|TanStack|Redis|MongoDB|CI\/CD|design systems?|system design|multiplayer|CRDT|Electron|GraphQL|REST|gRPC)\b/gi) ?? []) found.add(m);
	return [...found];
}
function quickTailor(profile, jobDescription) {
	const jd = jobDescription || "";
	const jdTokens = new Set(tokens(jd));
	const skillHits = [];
	const skillRest = [];
	for (const skill of profile.skills) (tokens(skill).some((t) => jdTokens.has(t)) || jd.toLowerCase().includes(skill.toLowerCase()) ? skillHits : skillRest).push(skill);
	const skills = [...skillHits, ...skillRest];
	const resumeBlob = [
		profile.headline,
		profile.summary,
		...profile.skills,
		...profile.experience.flatMap((e) => [
			e.title,
			e.company,
			...e.bullets
		]),
		...profile.projects.flatMap((p) => [p.name, ...p.bullets])
	].join(" ");
	const resumeTokens = new Set(tokens(resumeBlob));
	const important = phrases(jd);
	const keywordsHit = important.filter((k) => resumeBlob.toLowerCase().includes(k.toLowerCase()));
	const keywordsMissed = important.filter((k) => !resumeBlob.toLowerCase().includes(k.toLowerCase()));
	const overlap = [...jdTokens].filter((t) => resumeTokens.has(t)).length;
	const denom = Math.max(12, Math.min(jdTokens.size, 80));
	const matchScore = Math.max(35, Math.min(92, Math.round(overlap / denom * 100) + skillHits.length * 2));
	return {
		id: uid(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		headline: profile.headline,
		summary: profile.summary,
		skills,
		experience: profile.experience,
		education: profile.education,
		projects: profile.projects,
		matchScore,
		keywordsHit: keywordsHit.slice(0, 10),
		keywordsMissed: keywordsMissed.slice(0, 8),
		changes: ["Reordered skills so terms from the job description sit first.", "Left bullets unchanged — run Tailor with AI to rewrite emphasis."],
		coverNote: ""
	};
}
function ApplyPage() {
	const navigate = useNavigate();
	const profile = useVellum((s) => s.profile);
	const upsertApplication = useVellum((s) => s.upsertApplication);
	const saveTailored = useVellum((s) => s.saveTailored);
	const [company, setCompany] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [jobUrl, setJobUrl] = (0, import_react.useState)("");
	const [jobDescription, setJobDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [tailored, setTailored] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const preview = composeResume(profile, tailored);
	async function runAi() {
		if (!jobDescription.trim()) {
			toast("Paste a job description first");
			return;
		}
		setBusy("ai");
		setError(null);
		try {
			const result = await tailorResume({ data: {
				profile,
				company,
				role,
				jobDescription
			} });
			if (!result.ok) {
				setError(result.error);
				toast(result.error);
				return;
			}
			setTailored(result.resume);
			toast("Tailored resume ready");
		} catch {
			setError("Something went wrong talking to the tailor.");
			toast("Could not tailor this resume");
		} finally {
			setBusy(null);
		}
	}
	function runQuick() {
		if (!jobDescription.trim()) {
			toast("Paste a job description first");
			return;
		}
		setBusy("quick");
		setError(null);
		const next = quickTailor(profile, jobDescription);
		setTailored(next);
		setBusy(null);
		toast("Skills reordered from the job description");
	}
	function save(markApplied) {
		if (!company.trim() || !role.trim()) {
			toast("Add a company and role before saving");
			return;
		}
		setBusy("save");
		const app = createApplicationDraft({
			company: company.trim(),
			role: role.trim(),
			location: location.trim(),
			source: source.trim(),
			jobUrl: jobUrl.trim(),
			jobDescription,
			notes,
			status: markApplied ? "applied" : "draft",
			appliedAt: markApplied ? (/* @__PURE__ */ new Date()).toISOString() : null
		});
		upsertApplication(app);
		if (tailored) saveTailored(app.id, {
			...tailored,
			id: tailored.id
		});
		setBusy(null);
		toast(markApplied ? "Marked as applied" : "Saved to the board");
		navigate({
			to: "/applications/$id",
			params: { id: app.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 lg:col-span-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
						children: "New role"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl tracking-tight",
						children: "Tailor a resume"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Paste the job. Vellum rewrites emphasis — never the facts — and files the copy with this application."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Company",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: company,
								onChange: (e) => setCompany(e.target.value),
								placeholder: "Linear"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: role,
								onChange: (e) => setRole(e.target.value),
								placeholder: "Senior Product Engineer"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Location",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: location,
									onChange: (e) => setLocation(e.target.value),
									placeholder: "Remote"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Source",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: source,
									onChange: (e) => setSource(e.target.value),
									placeholder: "Referral, site…"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Posting URL",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: jobUrl,
								onChange: (e) => setJobUrl(e.target.value),
								placeholder: "https://"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Job description",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 12,
								value: jobDescription,
								onChange: (e) => setJobDescription(e.target.value),
								placeholder: "Paste the full posting…",
								className: "min-h-48"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Private notes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 3,
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								placeholder: "Recruiter name, referral, deadline…"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => void runAi(),
							disabled: busy !== null,
							children: [busy === "ai" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), "Tailor with AI"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: runQuick,
							disabled: busy !== null,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListFilter, {}), "Quick match (no rewrite)"]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}) : null
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 lg:col-span-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
						children: tailored ? "Tailored copy" : "Master (not yet tailored)"
					}), tailored?.matchScore != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Match score",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium tabular-nums text-foreground",
								children: tailored.matchScore
							})
						]
					}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, { resume: preview }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => save(false),
								disabled: busy !== null,
								children: "Save draft"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => save(true),
								disabled: busy !== null,
								children: "Save & mark applied"
							})
						]
					})]
				}),
				tailored ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchPanel, { tailored }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResumePaper, { resume: preview })
			]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function MatchPanel({ tailored }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-5 shadow-border",
		children: [
			tailored.changes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
				children: "What changed"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-1.5",
				children: tailored.changes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm leading-relaxed",
					children: c
				}, c))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("grid gap-4", tailored.changes.length > 0 && "mt-4 sm:grid-cols-2"),
				children: [tailored.keywordsHit.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
					children: "Hits"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-1.5",
					children: tailored.keywordsHit.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-success/12 px-2.5 py-0.5 text-xs text-success",
						children: k
					}, k))
				})] }) : null, tailored.keywordsMissed.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
					children: "Not claimed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-1.5",
					children: tailored.keywordsMissed.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-secondary px-2.5 py-0.5 text-xs text-muted-foreground",
						children: k
					}, k))
				})] }) : null]
			}),
			tailored.coverNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
					children: "Cover note"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed",
					children: tailored.coverNote
				})]
			}) : null
		]
	});
}
//#endregion
export { ApplyPage as component };
