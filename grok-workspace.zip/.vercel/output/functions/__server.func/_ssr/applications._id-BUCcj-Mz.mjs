import { i as __toESM } from "../_runtime.mjs";
import { n as formatDate } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as PenLine, n as Trash2, s as LoaderCircle, v as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as useVellum, n as Route } from "./router-CD1JqM-p.mjs";
import { a as ResumePaper, i as Label, n as ExportMenu, o as Textarea, r as Input, s as composeResume, t as Button } from "./textarea-CFxZJC2O.mjs";
import { a as SelectTrigger, c as StatusSelect, i as SelectItem, n as Select, o as SelectValue, r as SelectContent } from "./status-select-BFPxHDYW.mjs";
import { t as tailorResume } from "./tailor-BUF36r6V.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/applications._id-BUCcj-Mz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ApplicationDetail() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const application = useVellum((s) => s.applications.find((a) => a.id === id));
	const profile = useVellum((s) => s.profile);
	const resumes = useVellum((s) => s.resumes);
	const upsertApplication = useVellum((s) => s.upsertApplication);
	const setStatus = useVellum((s) => s.setStatus);
	const saveTailored = useVellum((s) => s.saveTailored);
	const deleteApplication = useVellum((s) => s.deleteApplication);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [view, setView] = (0, import_react.useState)("sent");
	const tailored = application?.tailoredResumeId ? resumes[application.tailoredResumeId] ?? null : null;
	const preview = (0, import_react.useMemo)(() => composeResume(profile, view === "master" ? null : tailored), [
		profile,
		tailored,
		view
	]);
	if (!application) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "This application is gone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "It may have been deleted from this browser’s ledger."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground",
				children: "Back to the board"
			})
		]
	});
	async function retailor() {
		if (!application) return;
		setBusy(true);
		try {
			const result = await tailorResume({ data: {
				profile,
				company: application.company,
				role: application.role,
				jobDescription: application.jobDescription
			} });
			if (!result.ok) {
				toast(result.error);
				return;
			}
			saveTailored(application.id, result.resume);
			setView("sent");
			toast("New tailored copy filed");
		} catch {
			toast("Could not tailor this resume");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 lg:col-span-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "inline-flex h-9 items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Board"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs font-medium tracking-widest text-muted-foreground uppercase",
						children: "Application"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-3xl tracking-tight",
						children: application.company
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted-foreground",
						children: application.role
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusSelect, {
						value: application.status,
						onChange: (status) => setStatus(application.id, status)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => {
							deleteApplication(application.id);
							toast("Removed from the ledger");
							navigate({ to: "/" });
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Delete"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
							label: "Opened",
							value: formatDate(application.createdAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
							label: "Applied",
							value: formatDate(application.appliedAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
							label: "Location",
							value: application.location || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {
							label: "Source",
							value: application.source || "—"
						})
					]
				}),
				application.jobUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: application.jobUrl,
					target: "_blank",
					rel: "noreferrer",
					className: "text-sm underline-offset-4 hover:underline",
					children: "Open posting"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 3,
						value: application.notes,
						onChange: (e) => upsertApplication({
							...application,
							notes: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Job description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 10,
						value: application.jobDescription,
						onChange: (e) => upsertApplication({
							...application,
							jobDescription: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Company" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: application.company,
						onChange: (e) => upsertApplication({
							...application,
							company: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Role" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: application.role,
						onChange: (e) => upsertApplication({
							...application,
							role: e.target.value
						})
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 lg:col-span-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
						children: "Resume on file"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [tailored ? `Custom version filed ${formatDate(tailored.createdAt)}` : "This role still uses the master resume", tailored?.matchScore != null ? ` · match ${tailored.matchScore}` : ""]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							tailored ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: view,
								onValueChange: (v) => setView(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-10 w-44",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "sent",
									children: "Version sent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "master",
									children: "Master resume"
								})] })]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, { resume: preview }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => void retailor(),
								disabled: busy,
								children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), tailored ? "Re-tailor" : "Tailor now"]
							})
						]
					})]
				}),
				tailored && view === "sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-card p-5 shadow-border",
					children: [tailored.changes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1.5",
						children: tailored.changes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm leading-relaxed",
							children: c
						}, c))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Filed without change notes."
					}), tailored.coverNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 border-t border-border pt-4 text-sm leading-relaxed",
						children: tailored.coverNote
					}) : null]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResumePaper, { resume: preview })
			]
		})]
	});
}
function Meta({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs tracking-wide text-muted-foreground uppercase",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-0.5",
		children: value
	})] });
}
//#endregion
export { ApplicationDetail as component };
