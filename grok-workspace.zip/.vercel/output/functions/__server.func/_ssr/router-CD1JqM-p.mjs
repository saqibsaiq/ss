import { i as __toESM } from "../_runtime.mjs";
import { i as uid, t as cn } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as PenLine, i as Plus, l as LayoutGrid, t as TriangleAlert, u as FileText } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CD1JqM-p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Toaster$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "light",
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast bg-card text-card-foreground shadow-border-hover border-0",
			title: "text-foreground",
			description: "text-muted-foreground"
		} }
	});
}
function TooltipProvider({ delayDuration = 200, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-accent", className),
		...props
	});
}
var SAMPLE_PROFILE = {
	fullName: "Maya Chen",
	headline: "Staff Software Engineer — product platforms & design systems",
	email: "maya.chen@example.com",
	phone: "+1 (415) 555-0148",
	location: "San Francisco, CA",
	website: "mayachen.dev",
	summary: "Staff engineer with 9 years shipping product platforms used by millions. I sit between design, product, and infrastructure — owning the systems that let teams move fast without breaking the craft. Recently led the editor platform at Northline (Series C), after building billing and dashboard foundations at Harbor.",
	skills: [
		"TypeScript",
		"React",
		"Node.js",
		"Postgres",
		"GraphQL",
		"Design systems",
		"TanStack",
		"AWS",
		"CI/CD",
		"System design",
		"Technical writing",
		"Mentorship"
	],
	experience: [
		{
			id: "exp-northline",
			company: "Northline",
			title: "Staff Software Engineer",
			location: "San Francisco, CA",
			start: "2022-04",
			end: "Present",
			bullets: [
				"Led the collaborative editor platform serving 1.4M weekly active users; cut p95 load time from 2.8s to 640ms.",
				"Designed the component and token system adopted by 6 product squads, retiring 40% of one-off UI.",
				"Built the real-time presence layer (CRDT + websockets) that unblocked simultaneous editing for enterprise seats.",
				"Mentored 5 engineers to senior; ran the weekly architecture review and incident postmortems."
			]
		},
		{
			id: "exp-harbor",
			company: "Harbor",
			title: "Senior Software Engineer",
			location: "New York, NY",
			start: "2019-06",
			end: "2022-03",
			bullets: [
				"Owned the billing and entitlements service processing $48M ARR with 99.99% invoice accuracy.",
				"Rebuilt the customer dashboard in React + TypeScript; NPS of the surface rose 18 points in two quarters.",
				"Introduced contract testing and a staged rollout pipeline that dropped production incidents 35%."
			]
		},
		{
			id: "exp-keel",
			company: "Keel Labs",
			title: "Software Engineer",
			location: "Remote",
			start: "2017-01",
			end: "2019-05",
			bullets: ["Shipped the first public API and webhook platform used by 200+ integration partners.", "Built internal admin tools that cut support ticket handle time by 40%."]
		}
	],
	education: [{
		id: "edu-cmu",
		school: "Carnegie Mellon University",
		degree: "B.S. Computer Science",
		year: "2016",
		detail: "Human-computer interaction minor"
	}],
	projects: [{
		id: "proj-vellum",
		name: "Open Tokens",
		url: "github.com/mayachen/open-tokens",
		bullets: ["Open-source design-token compiler used by 3k GitHub stars; transforms Figma variables into CSS, iOS, and Android."]
	}, {
		id: "proj-atlas",
		name: "Atlas Query",
		url: "atlasquery.dev",
		bullets: ["Read-only SQL notebook for product managers — shareable, permissioned, no warehouse credentials in the browser."]
	}]
};
var LINEAR_RESUME = {
	id: "resume-linear",
	createdAt: "2026-09-12T15:20:00.000Z",
	headline: "Staff Software Engineer — collaborative product, craft, and speed",
	summary: "Staff engineer who builds the kind of product Linear is known for: fast, considered, and quietly ambitious. Nine years across editor platforms, design systems, and real-time collaboration. I care about the last 10% — the feel of a surface — as much as the system underneath.",
	skills: [
		"TypeScript",
		"React",
		"Design systems",
		"TanStack",
		"Postgres",
		"Node.js",
		"System design",
		"Technical writing",
		"Mentorship",
		"GraphQL",
		"CI/CD",
		"AWS"
	],
	experience: [
		{
			id: "exp-northline",
			company: "Northline",
			title: "Staff Software Engineer",
			location: "San Francisco, CA",
			start: "2022-04",
			end: "Present",
			bullets: [
				"Led the collaborative editor used by 1.4M WAU; dropped p95 load from 2.8s to 640ms without sacrificing craft.",
				"Created the token and component system now used by 6 squads — the closest analog to a product-quality design system at a mid-stage company.",
				"Shipped real-time presence (CRDT + websockets) that made simultaneous editing feel native, not bolted on.",
				"Set the quality bar in architecture review; mentored 5 engineers to senior."
			]
		},
		{
			id: "exp-harbor",
			company: "Harbor",
			title: "Senior Software Engineer",
			location: "New York, NY",
			start: "2019-06",
			end: "2022-03",
			bullets: ["Rebuilt the customer dashboard in React + TypeScript; NPS of the surface rose 18 points in two quarters.", "Owned billing and entitlements ($48M ARR) with a staged rollout culture that cut incidents 35%."]
		},
		{
			id: "exp-keel",
			company: "Keel Labs",
			title: "Software Engineer",
			location: "Remote",
			start: "2017-01",
			end: "2019-05",
			bullets: ["Shipped the public API and webhook platform used by 200+ partners — small surface, high leverage."]
		}
	],
	education: SAMPLE_PROFILE.education,
	projects: SAMPLE_PROFILE.projects,
	matchScore: 86,
	keywordsHit: [
		"TypeScript",
		"React",
		"design systems",
		"collaboration",
		"performance",
		"craft"
	],
	keywordsMissed: ["Rust", "Electron"],
	changes: [
		"Reframed the summary around product craft and speed.",
		"Led with editor, design-system, and real-time work.",
		"Shortened Harbor/Keel to keep the page tight.",
		"Moved design systems and TanStack up in skills."
	],
	coverNote: "Linear’s bar for craft is the reason I’m writing. I’ve spent the last four years making an editor feel instant for a million people a week — tokens, presence, and the unglamorous work of making software feel inevitable. I’d like to do that on a product I already use every day."
};
var NOTION_RESUME = {
	id: "resume-notion",
	createdAt: "2026-09-08T18:04:00.000Z",
	headline: "Staff Software Engineer — documents, platforms, and multiplayer",
	summary: "Staff engineer specializing in document platforms and the systems around them. I led Northline’s collaborative editor (1.4M WAU), including CRDT presence, a cross-squad design system, and the performance work that made it feel local. Previously owned billing infrastructure and partner APIs.",
	skills: [
		"TypeScript",
		"React",
		"Postgres",
		"GraphQL",
		"Node.js",
		"Design systems",
		"System design",
		"AWS",
		"TanStack",
		"Technical writing",
		"Mentorship",
		"CI/CD"
	],
	experience: [
		{
			id: "exp-northline",
			company: "Northline",
			title: "Staff Software Engineer",
			location: "San Francisco, CA",
			start: "2022-04",
			end: "Present",
			bullets: [
				"Led the document editor platform (1.4M WAU) including block model, multiplayer, and permissioned sharing.",
				"Built CRDT-backed presence so teams could edit the same page without fighting the cursor.",
				"Scaled a token system across 6 squads so new surfaces shipped on-brand without a design bottleneck.",
				"Cut p95 load time from 2.8s to 640ms through code-splitting, query shaping, and edge caching."
			]
		},
		{
			id: "exp-harbor",
			company: "Harbor",
			title: "Senior Software Engineer",
			location: "New York, NY",
			start: "2019-06",
			end: "2022-03",
			bullets: ["Owned billing and entitlements processing $48M ARR — the unglamorous backbone of a workspace product.", "Rebuilt the customer dashboard; NPS of the surface rose 18 points in two quarters."]
		},
		{
			id: "exp-keel",
			company: "Keel Labs",
			title: "Software Engineer",
			location: "Remote",
			start: "2017-01",
			end: "2019-05",
			bullets: ["Launched the public API and webhooks used by 200+ partners to embed our data in their own tools."]
		}
	],
	education: SAMPLE_PROFILE.education,
	projects: [{
		id: "proj-atlas",
		name: "Atlas Query",
		url: "atlasquery.dev",
		bullets: ["SQL notebook for PMs — shareable, permissioned pages over the warehouse, no credentials in the browser."]
	}, SAMPLE_PROFILE.projects[0]],
	matchScore: 81,
	keywordsHit: [
		"documents",
		"multiplayer",
		"TypeScript",
		"React",
		"Postgres",
		"platforms"
	],
	keywordsMissed: ["Block protocol", "SQLite"],
	changes: [
		"Opened on document platforms and multiplayer.",
		"Reordered projects to lead with Atlas Query.",
		"Emphasized permissions, sharing, and block-model language."
	],
	coverNote: "I’ve been a Notion power user since the wiki days, and the problems you’re hiring for — documents as a platform, multiplayer that disappears, permissions that don’t fight the page — are the ones I’ve been living in at Northline."
};
var SAMPLE_RESUMES = {
	[LINEAR_RESUME.id]: LINEAR_RESUME,
	[NOTION_RESUME.id]: NOTION_RESUME
};
var SAMPLE_APPLICATIONS = [
	{
		id: "app-linear",
		company: "Linear",
		role: "Senior Product Engineer",
		location: "Remote — North America",
		source: "Company site",
		jobUrl: "https://linear.app/careers",
		jobDescription: `We're hiring a Senior Product Engineer to work on Linear's core product — issues, projects, and the editor. You will ship features end-to-end in TypeScript and React, sweat the interaction details, and raise the quality bar for a tool used by the best product teams in the world.

What we're looking for:
- Deep TypeScript and React
- Taste for product craft: motion, density, keyboard-first
- Experience with design systems and component libraries
- Comfortable with performance work (we care about 16ms frames)
- Written communication that would pass as a Linear update

Nice to have: Rust, Electron, sync engines, prior work on collaborative editors.`,
		status: "interview",
		appliedAt: "2026-09-14T16:00:00.000Z",
		createdAt: "2026-09-12T15:10:00.000Z",
		updatedAt: "2026-09-16T11:30:00.000Z",
		tailoredResumeId: LINEAR_RESUME.id,
		notes: "Recruiter screen 9/16. Hiring manager 9/22. Sent the craft-forward version."
	},
	{
		id: "app-notion",
		company: "Notion",
		role: "Software Engineer, Editor",
		location: "San Francisco, CA",
		source: "LinkedIn",
		jobUrl: "https://www.notion.so/careers",
		jobDescription: `The Editor team owns the document at the heart of Notion. We're looking for engineers who want to work on block models, multiplayer, permissions, and the performance of very large pages.

Requirements:
- 5+ years TypeScript/React
- Experience with document or productivity platforms
- Familiarity with CRDTs or operational transform a plus
- Postgres, GraphQL, and API design
- Empathy for a product used as a wiki, a tracker, and a database`,
		status: "applied",
		appliedAt: "2026-09-10T19:20:00.000Z",
		createdAt: "2026-09-08T17:50:00.000Z",
		updatedAt: "2026-09-10T19:20:00.000Z",
		tailoredResumeId: NOTION_RESUME.id,
		notes: "Submitted via Greenhouse. Used the editor/multiplayer version."
	},
	{
		id: "app-vercel",
		company: "Vercel",
		role: "Product Engineer, Dashboard",
		location: "Remote",
		source: "Referral — Priya N.",
		jobUrl: "https://vercel.com/careers",
		jobDescription: `Help us rebuild the Vercel dashboard: projects, deployments, observability, and the workflows teams live in every day. Product engineers here own UI through to the API.

Looking for:
- React, Next.js / TanStack, TypeScript
- Taste for dense, fast admin surfaces
- Comfort with design systems and tokens
- Interest in DX, preview deployments, and developer workflows`,
		status: "draft",
		appliedAt: null,
		createdAt: "2026-09-18T21:00:00.000Z",
		updatedAt: "2026-09-18T21:00:00.000Z",
		tailoredResumeId: null,
		notes: "Priya offered a referral. Tailor against the dashboard JD before sending."
	}
];
var emptySnapshot = () => ({
	profile: SAMPLE_PROFILE,
	applications: SAMPLE_APPLICATIONS,
	resumes: SAMPLE_RESUMES
});
function createApplicationDraft(patch = {}) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: uid(),
		company: "",
		role: "",
		location: "",
		source: "",
		jobUrl: "",
		jobDescription: "",
		status: "draft",
		appliedAt: null,
		createdAt: now,
		updatedAt: now,
		tailoredResumeId: null,
		notes: "",
		...patch
	};
}
var useVellum = create()(persist((set, get) => ({
	...emptySnapshot(),
	hasHydrated: false,
	setHasHydrated: (value) => set({ hasHydrated: value }),
	setProfile: (profile) => set({ profile }),
	patchProfile: (patch) => set({ profile: {
		...get().profile,
		...patch
	} }),
	upsertApplication: (application) => set((state) => {
		return { applications: state.applications.some((a) => a.id === application.id) ? state.applications.map((a) => a.id === application.id ? {
			...application,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : a) : [{
			...application,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, ...state.applications] };
	}),
	setStatus: (id, status) => set((state) => ({ applications: state.applications.map((a) => a.id === id ? {
		...a,
		status,
		appliedAt: status === "applied" && !a.appliedAt ? (/* @__PURE__ */ new Date()).toISOString() : a.appliedAt,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	} : a) })),
	saveTailored: (applicationId, resume) => set((state) => ({
		resumes: {
			...state.resumes,
			[resume.id]: resume
		},
		applications: state.applications.map((a) => a.id === applicationId ? {
			...a,
			tailoredResumeId: resume.id,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : a)
	})),
	deleteApplication: (id) => set((state) => {
		const target = state.applications.find((a) => a.id === id);
		const resumes = { ...state.resumes };
		if (target?.tailoredResumeId) {
			if (!state.applications.some((a) => a.id !== id && a.tailoredResumeId === target.tailoredResumeId)) delete resumes[target.tailoredResumeId];
		}
		return {
			applications: state.applications.filter((a) => a.id !== id),
			resumes
		};
	}),
	resetWorkspace: () => set({ ...emptySnapshot() }),
	importSnapshot: (snapshot) => set({
		profile: snapshot.profile,
		applications: snapshot.applications,
		resumes: snapshot.resumes
	})
}), {
	name: "vellum-workspace",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		profile: state.profile,
		applications: state.applications,
		resumes: state.resumes
	})
}));
var NAV = [
	{
		to: "/",
		label: "Board",
		icon: LayoutGrid
	},
	{
		to: "/apply",
		label: "Tailor",
		icon: PenLine
	},
	{
		to: "/resume",
		label: "Master",
		icon: FileText
	}
];
function AppShell({ children }) {
	const hasHydrated = useVellum((s) => s.hasHydrated);
	(0, import_react.useEffect)(() => {
		useVellum.persist.rehydrate().finally(() => {
			useVellum.getState().setHasHydrated(true);
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:grid lg:grid-cols-[15.5rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "no-print hidden lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:border-r lg:border-border lg:bg-studio/60 lg:px-5 lg:py-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "mt-10 flex flex-col gap-1",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, { ...item }, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/apply",
							className: "mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-3 text-sm font-medium text-primary-foreground shadow-border transition-[opacity,transform] duration-150 ease-out hover:opacity-90 active:scale-[0.96]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New application"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-auto pt-8 text-xs leading-relaxed text-muted-foreground",
							children: "One master resume. A tailored copy for every role. A ledger of what you sent."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-dvh flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "no-print sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-background/90 px-4 backdrop-blur-sm lg:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/apply",
							className: "inline-flex h-10 items-center gap-1.5 rounded-md bg-primary px-3 text-sm font-medium text-primary-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Tailor"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 px-4 py-6 pb-24 sm:px-6 lg:px-10 lg:py-8 lg:pb-10",
						children: hasHydrated ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShellSkeleton, {})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "no-print fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-border bg-background/95 backdrop-blur-sm lg:hidden",
				children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
					...item,
					mobile: true
				}, item.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})
		]
	}) });
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-center gap-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-8 items-center justify-center rounded-md bg-primary font-display text-sm text-primary-foreground",
				children: "V"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg tracking-tight",
				children: "Vellum"
			}),
			compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-0.5 text-xs text-muted-foreground",
				children: "atelier"
			})
		]
	});
}
function NavLink({ to, label, icon: Icon, mobile = false }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const active = pathname === to || to !== "/" && pathname.startsWith(to);
	if (mobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium", active ? "text-foreground" : "text-muted-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("flex h-11 items-center gap-2.5 rounded-md px-3 text-sm font-medium transition-colors duration-150", active ? "bg-card text-foreground shadow-border" : "text-muted-foreground hover:bg-accent hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
function ShellSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-96 max-w-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" })
		]
	});
}
var styles_default = "/assets/styles-DW2jH94c.css";
var APP_NAME = "Vellum";
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Tailor a resume for every job. Keep a ledger of which version you sent."
			},
			{
				name: "theme-color",
				content: "#F3F1EC"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;1,400&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$3 = () => import("./routes-CMq1qDWL.mjs");
var Route$3 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./apply-BHpeNWaa.mjs");
var Route$2 = createFileRoute("/apply")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./resume-Jb-LptJy.mjs");
var Route$1 = createFileRoute("/resume")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./applications._id-BUCcj-Mz.mjs");
var Route = createFileRoute("/applications/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ApplyRoute: Route$2.update({
		id: "/apply",
		path: "/apply",
		getParentRoute: () => Route$4
	}),
	ResumeRoute: Route$1.update({
		id: "/resume",
		path: "/resume",
		getParentRoute: () => Route$4
	}),
	ApplicationsIdRoute: Route.update({
		id: "/applications/$id",
		path: "/applications/$id",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useVellum as i, Route as n, createApplicationDraft as r, router_exports as t };
