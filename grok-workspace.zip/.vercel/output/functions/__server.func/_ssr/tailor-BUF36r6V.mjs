import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tailor-BUF36r6V.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tailorResume = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("d4e09d3ffc43b223726143786dc582610d6a98b2b738f179f502d859a8386215"));
//#endregion
export { tailorResume as t };
