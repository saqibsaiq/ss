import "../_runtime.mjs";
import { n as formatDate, t as cn } from "./utils-S0PEXG6m.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ArrowUpRight, f as FileCheck2, g as Briefcase, o as MessagesSquare } from "../_libs/lucide-react.mjs";
import { i as useVellum } from "./router-CD1JqM-p.mjs";
import { s as StatusBadge, t as PIPELINE_COLUMNS } from "./status-select-BFPxHDYW.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl bg-card text-card-foreground shadow-border", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("p-5", className),
		...props
	});
}
function Board() {
	const applications = useVellum((s) => s.applications);
	const resumes = useVellum((s) => s.resumes);
	const firstName = useVellum((s) => s.profile).fullName.trim().split(/\s+/)[0] || "Your";
	const applied = applications.filter((a) => a.status !== "draft").length;
	const interviews = applications.filter((a) => a.status === "interview" || a.status === "offer").length;
	const tailored = applications.filter((a) => a.tailoredResumeId).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-widest text-muted-foreground uppercase",
						children: "Application board"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-1 font-display text-3xl tracking-tight sm:text-4xl",
						children: [firstName, "’s ledger"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: "Every role gets its own resume. Open a card to see the exact version that went out."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/apply",
					className: "inline-flex h-11 items-center justify-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground shadow-border transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.96]",
					children: "Tailor for a new role"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Briefcase,
						label: "Roles in play",
						value: applied,
						hint: "Anything past draft"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: MessagesSquare,
						label: "Conversations",
						value: interviews,
						hint: "Interview or offer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: FileCheck2,
						label: "Tailored copies",
						value: tailored,
						hint: "Versions on file"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "hidden gap-3 lg:grid lg:grid-cols-4",
				children: PIPELINE_COLUMNS.map((col) => {
					const items = applications.filter((a) => col.statuses.includes(a.status));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-80 flex-col rounded-xl bg-studio/70 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-baseline justify-between px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: col.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tabular-nums text-muted-foreground",
								children: items.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-1 flex-col gap-2",
							children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-1 text-xs text-muted-foreground",
								children: "Nothing here yet."
							}) : items.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplicationCard, {
								app,
								tailored: Boolean(app.tailoredResumeId && resumes[app.tailoredResumeId])
							}, app.id))
						})]
					}, col.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "flex flex-col gap-2 lg:hidden",
				children: applications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyBoard, {}) : applications.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplicationCard, {
					app,
					tailored: Boolean(app.tailoredResumeId && resumes[app.tailoredResumeId])
				}, app.id))
			})
		]
	});
}
function Stat({ icon: Icon, label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "flex items-start gap-3 p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-10 items-center justify-center rounded-lg bg-secondary text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-3xl tabular-nums leading-none",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-xs text-muted-foreground",
				children: hint
			})
		] })]
	}) });
}
function ApplicationCard({ app, tailored }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/applications/$id",
		params: { id: app.id },
		className: "block rounded-lg bg-card p-4 shadow-border transition-[box-shadow,transform] duration-150 hover:shadow-border-hover",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-medium",
						children: app.company || "Untitled company"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted-foreground",
						children: app.role || "Untitled role"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 shrink-0 text-muted-foreground" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: app.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: tailored ? "Custom resume on file" : "Master resume"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted-foreground",
				children: app.appliedAt ? `Applied ${formatDate(app.appliedAt)}` : `Opened ${formatDate(app.createdAt)}`
			})
		]
	});
}
function EmptyBoard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card px-6 py-12 text-center shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl",
				children: "No applications yet"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Paste a job description and Vellum will cut a resume for that role."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/apply",
				className: "mt-5 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground",
				children: "Start the first one"
			})
		]
	});
}
//#endregion
export { Board as component };
