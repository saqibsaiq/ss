//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-RF7CbpXh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/apply",
			"/resume",
			"/applications/$id"
		],
		preloads: [
			"/assets/index-BjRjytyO.js",
			"/assets/store-C2DHdDJs.js",
			"/assets/useRouter-CCIUEwfl.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BjRjytyO.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B5EvT_pO.js", "/assets/status-select-BDbBC1Zm.js"]
	},
	"/apply": {
		filePath: "/workspace/src/routes/apply.tsx",
		children: void 0,
		preloads: [
			"/assets/apply-ByVnF43_.js",
			"/assets/tailor-DKds2hoF.js",
			"/assets/textarea-Dko-wTO2.js"
		]
	},
	"/resume": {
		filePath: "/workspace/src/routes/resume.tsx",
		children: void 0,
		preloads: [
			"/assets/resume-C8l7CqVN.js",
			"/assets/textarea-Dko-wTO2.js",
			"/assets/trash-2-BTbRIbl-.js"
		]
	},
	"/applications/$id": {
		filePath: "/workspace/src/routes/applications.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/applications._id-BGpF1mVb.js",
			"/assets/tailor-DKds2hoF.js",
			"/assets/status-select-BDbBC1Zm.js",
			"/assets/textarea-Dko-wTO2.js",
			"/assets/trash-2-BTbRIbl-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
