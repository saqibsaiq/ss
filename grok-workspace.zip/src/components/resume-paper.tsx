import type { ReactNode } from "react";
import { formatMonth } from "@/lib/utils";
import { contactLine } from "@/lib/resume-text";
import type { MasterResume } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ResumePaper({
  resume,
  className,
  compact = false,
}: {
  resume: MasterResume;
  className?: string;
  compact?: boolean;
}) {
  const contact = contactLine(resume);

  return (
    <article
      className={cn(
        "print-paper bg-paper text-ink shadow-paper",
        compact ? "rounded-lg px-6 py-7" : "rounded-lg px-8 py-10 sm:px-11 sm:py-12",
        className,
      )}
    >
      <header className="text-center">
        <h1
          className={cn(
            "font-display font-medium tracking-tight text-balance",
            compact ? "text-2xl" : "text-3xl sm:text-4xl",
          )}
        >
          {resume.fullName || "Your name"}
        </h1>
        {resume.headline ? (
          <p
            className={cn(
              "mt-2 text-muted-foreground",
              compact ? "text-sm" : "text-sm sm:text-base",
            )}
          >
            {resume.headline}
          </p>
        ) : null}
        {contact ? (
          <p className="mt-3 text-xs tracking-wide text-muted-foreground">
            {contact}
          </p>
        ) : null}
      </header>

      {resume.summary ? (
        <Section title="Summary" compact={compact}>
          <p className={cn("leading-relaxed", compact ? "text-sm" : "text-sm sm:text-[0.9375rem]")}>
            {resume.summary}
          </p>
        </Section>
      ) : null}

      {resume.skills.length > 0 ? (
        <Section title="Skills" compact={compact}>
          <p className="text-sm leading-relaxed">{resume.skills.join("  ·  ")}</p>
        </Section>
      ) : null}

      {resume.experience.length > 0 ? (
        <Section title="Experience" compact={compact}>
          <div className="flex flex-col gap-5">
            {resume.experience.map((job) => (
              <div key={job.id}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                  <h3 className="text-sm font-semibold">
                    {job.title}
                    {job.company ? (
                      <span className="font-normal text-muted-foreground">
                        {" "}
                        — {job.company}
                      </span>
                    ) : null}
                  </h3>
                  <span className="text-xs tabular-nums text-muted-foreground">
                    {formatMonth(job.start)}
                    {job.start ? " – " : ""}
                    {formatMonth(job.end) || "Present"}
                  </span>
                </div>
                {job.location ? (
                  <p className="mt-0.5 text-xs text-muted-foreground">{job.location}</p>
                ) : null}
                {job.bullets.filter(Boolean).length > 0 ? (
                  <ul className="mt-2 flex flex-col gap-1.5">
                    {job.bullets.filter(Boolean).map((b, i) => (
                      <li
                        key={`${job.id}-${i}`}
                        className="relative pl-3.5 text-sm leading-relaxed before:absolute before:left-0 before:top-2 before:size-1 before:rounded-full before:bg-foreground/50"
                      >
                        {b}
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            ))}
          </div>
        </Section>
      ) : null}

      {resume.projects.length > 0 ? (
        <Section title="Projects" compact={compact}>
          <div className="flex flex-col gap-4">
            {resume.projects.map((p) => (
              <div key={p.id}>
                <h3 className="text-sm font-semibold">
                  {p.name}
                  {p.url ? (
                    <span className="ml-2 font-normal text-muted-foreground">{p.url}</span>
                  ) : null}
                </h3>
                {p.bullets.filter(Boolean).length > 0 ? (
                  <ul className="mt-1.5 flex flex-col gap-1">
                    {p.bullets.filter(Boolean).map((b, i) => (
                      <li
                        key={`${p.id}-${i}`}
                        className="relative pl-3.5 text-sm leading-relaxed before:absolute before:left-0 before:top-2 before:size-1 before:rounded-full before:bg-foreground/50"
                      >
                        {b}
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            ))}
          </div>
        </Section>
      ) : null}

      {resume.education.length > 0 ? (
        <Section title="Education" compact={compact}>
          {resume.education.map((e) => (
            <div key={e.id} className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-sm">
                <span className="font-semibold">{e.degree}</span>
                {e.school ? ` — ${e.school}` : ""}
                {e.detail ? (
                  <span className="text-muted-foreground"> · {e.detail}</span>
                ) : null}
              </p>
              <span className="text-xs tabular-nums text-muted-foreground">{e.year}</span>
            </div>
          ))}
        </Section>
      ) : null}
    </article>
  );
}

function Section({
  title,
  children,
  compact,
}: {
  title: string;
  children: ReactNode;
  compact: boolean;
}) {
  return (
    <section className={cn(compact ? "mt-6" : "mt-8")}>
      <h2 className="mb-2.5 border-b border-foreground/12 pb-1 font-sans text-xs font-semibold tracking-widest text-muted-foreground uppercase">
        {title}
      </h2>
      {children}
    </section>
  );
}
