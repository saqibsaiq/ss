import { Link, useRouterState } from "@tanstack/react-router";
import { FileText, LayoutGrid, PenLine, Plus } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useVellum } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Board", icon: LayoutGrid },
  { to: "/apply", label: "Tailor", icon: PenLine },
  { to: "/resume", label: "Master", icon: FileText },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  useEffect(() => {
    void useVellum.persist.rehydrate();
  }, []);

  return (
    <TooltipProvider>
      <div className="min-h-dvh bg-background text-foreground">
        <div className="lg:grid lg:grid-cols-[16rem_minmax(0,1fr)]">
          <aside className="no-print hidden lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:border-r lg:border-border lg:bg-studio/60 lg:px-5 lg:py-7">
            <Brand />
            <nav className="mt-10 flex flex-col gap-1">
              {NAV.map((item) => (
                <NavLink key={item.to} {...item} />
              ))}
            </nav>
            <Link
              to="/apply"
              className="mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-md bg-primary px-3 text-sm font-medium text-primary-foreground shadow-border transition-[opacity,transform] duration-150 ease-out hover:opacity-90 active:scale-[0.96]"
            >
              <Plus className="size-4" />
              New application
            </Link>
            <p className="mt-auto pt-8 text-xs leading-relaxed text-muted-foreground">
              One master resume. A tailored copy for every role. A ledger of what you sent.
            </p>
          </aside>

          <div className="flex min-h-dvh flex-col">
            <header className="no-print sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-background/90 px-4 backdrop-blur-sm lg:hidden">
              <Brand compact />
              <Link
                to="/apply"
                className="inline-flex h-10 items-center gap-1.5 rounded-md bg-primary px-3 text-sm font-medium text-primary-foreground"
              >
                <Plus className="size-4" />
                Tailor
              </Link>
            </header>

            <main className="flex-1 px-4 py-6 pb-24 sm:px-6 lg:px-10 lg:py-8 lg:pb-10">
              {children}
            </main>
          </div>
        </div>

        <nav className="no-print fixed inset-x-0 bottom-0 z-30 grid grid-cols-3 border-t border-border bg-background/95 backdrop-blur-sm lg:hidden">
          {NAV.map((item) => (
            <NavLink key={item.to} {...item} mobile />
          ))}
        </nav>
        <Toaster />
      </div>
    </TooltipProvider>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="flex size-8 items-center justify-center rounded-md bg-primary font-display text-sm text-primary-foreground">
        V
      </span>
      <span className="font-display text-lg tracking-tight">Vellum</span>
      {compact ? null : (
        <span className="ml-0.5 text-xs text-muted-foreground">atelier</span>
      )}
    </Link>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  mobile = false,
}: {
  to: "/" | "/apply" | "/resume";
  label: string;
  icon: typeof LayoutGrid;
  mobile?: boolean;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const active = pathname === to || (to !== "/" && pathname.startsWith(to));

  if (mobile) {
    return (
      <Link
        to={to}
        className={cn(
          "flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium",
          active ? "text-foreground" : "text-muted-foreground",
        )}
      >
        <Icon className="size-4" />
        {label}
      </Link>
    );
  }

  return (
    <Link
      to={to}
      className={cn(
        "flex h-11 items-center gap-2.5 rounded-md px-3 text-sm font-medium transition-colors duration-150",
        active
          ? "bg-card text-foreground shadow-border"
          : "text-muted-foreground hover:bg-accent hover:text-foreground",
      )}
    >
      <Icon className="size-4" />
      {label}
    </Link>
  );
}
