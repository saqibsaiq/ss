import { Copy, FileDown, Printer } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  copyText,
  resumeToMarkdown,
  resumeToPlainText,
} from "@/lib/resume-text";
import type { MasterResume } from "@/lib/types";

export function ExportMenu({ resume }: { resume: MasterResume }) {
  async function copy(kind: "text" | "md") {
    const body =
      kind === "md" ? resumeToMarkdown(resume) : resumeToPlainText(resume);
    const ok = await copyText(body);
    toast(ok ? "Copied to clipboard" : "Could not copy");
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <FileDown />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onSelect={() => void copy("text")}>
          <Copy className="size-4" />
          Copy as text
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => void copy("md")}>
          <Copy className="size-4" />
          Copy as Markdown
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => window.print()}>
          <Printer className="size-4" />
          Print / save PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
