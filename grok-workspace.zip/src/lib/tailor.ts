    if (!res.ok) {
      if (res.status === 403 || res.status === 401 || res.status === 402) {
        return {
          ok: false,
          error:
            "AI tailor is unavailable right now. Use Quick match to line skills up with the posting, then edit bullets yourself.",
        };
      }
      return { ok: false, error: `The tailor could not reach the model (${res.status}).` };
    }