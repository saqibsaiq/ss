export const APPLICATION_STATUSES = [
  "draft",
  "applied",
  "interview",
  "offer",
  "rejected",
  "withdrawn",
] as const;

export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

export type Experience = {
  id: string;
  company: string;
  title: string;
  location: string;
  start: string;
  end: string;
  bullets: string[];
};

export type Education = {
  id: string;
  school: string;
  degree: string;
  year: string;
  detail: string;
};

export type Project = {
  id: string;
  name: string;
  url: string;
  bullets: string[];
};

export type MasterResume = {
  fullName: string;
  headline: string;
  email: string;
  phone: string;
  location: string;
  website: string;
  summary: string;
  skills: string[];
  experience: Experience[];
  education: Education[];
  projects: Project[];
};

export type TailoredResume = {
  id: string;
  createdAt: string;
  headline: string;
  summary: string;
  skills: string[];
  experience: Experience[];
  education: Education[];
  projects: Project[];
  matchScore: number | null;
  keywordsHit: string[];
  keywordsMissed: string[];
  changes: string[];
  coverNote: string;
};

export type Application = {
  id: string;
  company: string;
  role: string;
  location: string;
  source: string;
  jobUrl: string;
  jobDescription: string;
  status: ApplicationStatus;
  appliedAt: string | null;
  createdAt: string;
  updatedAt: string;
  tailoredResumeId: string | null;
  notes: string;
};

export type VellumSnapshot = {
  profile: MasterResume;
  applications: Application[];
  resumes: Record<string, TailoredResume>;
};

export const STATUS_LABEL: Record<ApplicationStatus, string> = {
  draft: "Draft",
  applied: "Applied",
  interview: "Interview",
  offer: "Offer",
  rejected: "Rejected",
  withdrawn: "Withdrawn",
};

export const PIPELINE_COLUMNS: {
  key: string;
  label: string;
  statuses: ApplicationStatus[];
}[] = [
  { key: "draft", label: "Draft", statuses: ["draft"] },
  { key: "applied", label: "Applied", statuses: ["applied"] },
  { key: "interview", label: "Interview", statuses: ["interview"] },
  {
    key: "closed",
    label: "Decision",
    statuses: ["offer", "rejected", "withdrawn"],
  },
];
