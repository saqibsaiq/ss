import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import {
  SAMPLE_APPLICATIONS,
  SAMPLE_PROFILE,
  SAMPLE_RESUMES,
} from "./sample-data";
import type {
  Application,
  ApplicationStatus,
  MasterResume,
  TailoredResume,
  VellumSnapshot,
} from "./types";
import { uid } from "./utils";

type VellumState = VellumSnapshot & {
  setProfile: (profile: MasterResume) => void;
  patchProfile: (patch: Partial<MasterResume>) => void;
  upsertApplication: (application: Application) => void;
  setStatus: (id: string, status: ApplicationStatus) => void;
  saveTailored: (applicationId: string, resume: TailoredResume) => void;
  deleteApplication: (id: string) => void;
  resetWorkspace: () => void;
  importSnapshot: (snapshot: VellumSnapshot) => void;
};

const emptySnapshot = (): VellumSnapshot => ({
  profile: SAMPLE_PROFILE,
  applications: SAMPLE_APPLICATIONS,
  resumes: SAMPLE_RESUMES,
});

export function createApplicationDraft(
  patch: Partial<Application> = {},
): Application {
  const now = new Date().toISOString();
  return {
    id: uid(),
    company: "",
    role: "",
    location: "",
    source: "",
    jobUrl: "",
    jobDescription: "",
    status: "draft",
    appliedAt: null,
    createdAt: now,
    updatedAt: now,
    tailoredResumeId: null,
    notes: "",
    ...patch,
  };
}

export const useVellum = create<VellumState>()(
  persist(
    (set, get) => ({
      ...emptySnapshot(),
      setProfile: (profile) => set({ profile }),
      patchProfile: (patch) =>
        set({ profile: { ...get().profile, ...patch } }),
      upsertApplication: (application) =>
        set((state) => {
          const exists = state.applications.some((a) => a.id === application.id);
          const next = exists
            ? state.applications.map((a) =>
                a.id === application.id
                  ? { ...application, updatedAt: new Date().toISOString() }
                  : a,
              )
            : [
                { ...application, updatedAt: new Date().toISOString() },
                ...state.applications,
              ];
          return { applications: next };
        }),
      setStatus: (id, status) =>
        set((state) => ({
          applications: state.applications.map((a) =>
            a.id === id
              ? {
                  ...a,
                  status,
                  appliedAt:
                    status === "applied" && !a.appliedAt
                      ? new Date().toISOString()
                      : a.appliedAt,
                  updatedAt: new Date().toISOString(),
                }
              : a,
          ),
        })),
      saveTailored: (applicationId, resume) =>
        set((state) => ({
          resumes: { ...state.resumes, [resume.id]: resume },
          applications: state.applications.map((a) =>
            a.id === applicationId
              ? {
                  ...a,
                  tailoredResumeId: resume.id,
                  updatedAt: new Date().toISOString(),
                }
              : a,
          ),
        })),
      deleteApplication: (id) =>
        set((state) => {
          const target = state.applications.find((a) => a.id === id);
          const resumes = { ...state.resumes };
          if (target?.tailoredResumeId) {
            const usedElsewhere = state.applications.some(
              (a) =>
                a.id !== id && a.tailoredResumeId === target.tailoredResumeId,
            );
            if (!usedElsewhere) delete resumes[target.tailoredResumeId];
          }
          return {
            applications: state.applications.filter((a) => a.id !== id),
            resumes,
          };
        }),
      resetWorkspace: () => set({ ...emptySnapshot() }),
      importSnapshot: (snapshot) =>
        set({
          profile: snapshot.profile,
          applications: snapshot.applications,
          resumes: snapshot.resumes,
        }),
    }),
    {
      name: "vellum-workspace",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        profile: state.profile,
        applications: state.applications,
        resumes: state.resumes,
      }),
    },
  ),
);

export function resumeForApplication(
  state: Pick<VellumState, "profile" | "resumes">,
  application: Application,
): { resume: MasterResume | TailoredResume; tailored: boolean } {
  if (application.tailoredResumeId && state.resumes[application.tailoredResumeId]) {
    return {
      resume: state.resumes[application.tailoredResumeId],
      tailored: true,
    };
  }
  return { resume: state.profile, tailored: false };
}
