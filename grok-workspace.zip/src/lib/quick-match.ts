import type { MasterResume, TailoredResume } from "./types";
import { uid } from "./utils";

const STOP = new Set(
  "a an the and or of to for in on with without from by as at is are be this that those these we you your our their they it its into over under than then also will can should must have has had using use used about across after before between among per via such other more most any all not no yes".split(
    " ",
  ),
);

function tokens(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9+.#\s-]/g, " ")
    .split(/[\s,/|]+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 2 && !STOP.has(t));
}

function phrases(text: string): string[] {
  const found = new Set<string>();
  const re =
    /\b(?:TypeScript|JavaScript|React|Node\.?js|GraphQL|Postgres(?:ql)?|PostgreSQL|AWS|GCP|Azure|Kubernetes|Docker|Python|Go|Rust|Java|Kotlin|Swift|Next\.js|TanStack|Redis|MongoDB|CI\/CD|design systems?|system design|multiplayer|CRDT|Electron|GraphQL|REST|gRPC)\b/gi;
  for (const m of text.match(re) ?? []) found.add(m);
  return [...found];
}

export function quickTailor(
  profile: MasterResume,
  jobDescription: string,
): TailoredResume {
  const jd = jobDescription || "";
  const jdTokens = new Set(tokens(jd));
  const skillHits: string[] = [];
  const skillRest: string[] = [];
  for (const skill of profile.skills) {
    const hit = tokens(skill).some((t) => jdTokens.has(t)) ||
      jd.toLowerCase().includes(skill.toLowerCase());
    (hit ? skillHits : skillRest).push(skill);
  }
  const skills = [...skillHits, ...skillRest];

  const resumeBlob = [
    profile.headline,
    profile.summary,
    ...profile.skills,
    ...profile.experience.flatMap((e) => [e.title, e.company, ...e.bullets]),
    ...profile.projects.flatMap((p) => [p.name, ...p.bullets]),
  ].join(" ");
  const resumeTokens = new Set(tokens(resumeBlob));

  const important = phrases(jd);
  const keywordsHit = important.filter((k) =>
    resumeBlob.toLowerCase().includes(k.toLowerCase()),
  );
  const keywordsMissed = important.filter(
    (k) => !resumeBlob.toLowerCase().includes(k.toLowerCase()),
  );

  const overlap = [...jdTokens].filter((t) => resumeTokens.has(t)).length;
  const denom = Math.max(12, Math.min(jdTokens.size, 80));
  const matchScore = Math.max(
    35,
    Math.min(92, Math.round((overlap / denom) * 100) + skillHits.length * 2),
  );

  return {
    id: uid(),
    createdAt: new Date().toISOString(),
    headline: profile.headline,
    summary: profile.summary,
    skills,
    experience: profile.experience,
    education: profile.education,
    projects: profile.projects,
    matchScore,
    keywordsHit: keywordsHit.slice(0, 10),
    keywordsMissed: keywordsMissed.slice(0, 8),
    changes: [
      "Reordered skills so terms from the job description sit first.",
      "Left bullets unchanged — run Tailor with AI to rewrite emphasis.",
    ],
    coverNote: "",
  };
}
