import { formatMonth } from "./utils";
import type { MasterResume, TailoredResume } from "./types";

export type AnyResume = MasterResume | TailoredResume;

export function composeResume(
  profile: MasterResume,
  tailored?: TailoredResume | null,
): MasterResume {
  if (!tailored) return profile;
  return {
    ...profile,
    headline: tailored.headline,
    summary: tailored.summary,
    skills: tailored.skills,
    experience: tailored.experience,
    education: tailored.education.length ? tailored.education : profile.education,
    projects: tailored.projects,
  };
}

export function contactLine(resume: MasterResume): string {
  return [resume.location, resume.email, resume.phone, resume.website]
    .filter(Boolean)
    .join("  ·  ");
}

export function resumeToPlainText(resume: MasterResume): string {
  const lines: string[] = [];
  lines.push(resume.fullName);
  if (resume.headline) lines.push(resume.headline);
  const contact = contactLine(resume);
  if (contact) lines.push(contact);
  lines.push("");
  if (resume.summary) {
    lines.push("SUMMARY");
    lines.push(resume.summary);
    lines.push("");
  }
  if (resume.skills?.length) {
    lines.push("SKILLS");
    lines.push(resume.skills.join(" · "));
    lines.push("");
  }
  if (resume.experience?.length) {
    lines.push("EXPERIENCE");
    for (const job of resume.experience) {
      lines.push(
        `${job.title} — ${job.company}  (${formatMonth(job.start)} – ${formatMonth(job.end)})`,
      );
      if (job.location) lines.push(job.location);
      for (const b of job.bullets.filter(Boolean)) lines.push(`• ${b}`);
      lines.push("");
    }
  }
  if (resume.projects?.length) {
    lines.push("PROJECTS");
    for (const p of resume.projects) {
      lines.push(p.url ? `${p.name} — ${p.url}` : p.name);
      for (const b of p.bullets.filter(Boolean)) lines.push(`• ${b}`);
      lines.push("");
    }
  }
  if (resume.education?.length) {
    lines.push("EDUCATION");
    for (const e of resume.education) {
      lines.push(`${e.degree} — ${e.school}, ${e.year}`);
      if (e.detail) lines.push(e.detail);
    }
  }
  return lines.join("\n").trim();
}

export function resumeToMarkdown(resume: MasterResume): string {
  const lines: string[] = [];
  lines.push(`# ${resume.fullName}`);
  if (resume.headline) lines.push(`*${resume.headline}*`);
  const contact = contactLine(resume);
  if (contact) lines.push(contact);
  lines.push("");
  if (resume.summary) {
    lines.push("## Summary");
    lines.push(resume.summary);
    lines.push("");
  }
  if (resume.skills?.length) {
    lines.push("## Skills");
    lines.push(resume.skills.join(" · "));
    lines.push("");
  }
  if (resume.experience?.length) {
    lines.push("## Experience");
    for (const job of resume.experience) {
      lines.push(`### ${job.title} — ${job.company}`);
      lines.push(
        `*${formatMonth(job.start)} – ${formatMonth(job.end)}${job.location ? ` · ${job.location}` : ""}*`,
      );
      for (const b of job.bullets.filter(Boolean)) lines.push(`- ${b}`);
      lines.push("");
    }
  }
  if (resume.projects?.length) {
    lines.push("## Projects");
    for (const p of resume.projects) {
      lines.push(`### ${p.name}`);
      if (p.url) lines.push(`*${p.url}*`);
      for (const b of p.bullets.filter(Boolean)) lines.push(`- ${b}`);
      lines.push("");
    }
  }
  if (resume.education?.length) {
    lines.push("## Education");
    for (const e of resume.education) {
      lines.push(`**${e.degree}**, ${e.school} (${e.year})`);
      if (e.detail) lines.push(e.detail);
    }
  }
  return lines.join("\n").trim();
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
