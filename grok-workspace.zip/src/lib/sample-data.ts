import type { Application, MasterResume, TailoredResume } from "./types";

export const SAMPLE_PROFILE: MasterResume = {
  fullName: "Maya Chen",
  headline: "Staff Software Engineer — product platforms & design systems",
  email: "maya.chen@example.com",
  phone: "+1 (415) 555-0148",
  location: "San Francisco, CA",
  website: "mayachen.dev",
  summary:
    "Staff engineer with 9 years shipping product platforms used by millions. I sit between design, product, and infrastructure — owning the systems that let teams move fast without breaking the craft. Recently led the editor platform at Northline (Series C), after building billing and dashboard foundations at Harbor.",
  skills: [
    "TypeScript",
    "React",
    "Node.js",
    "Postgres",
    "GraphQL",
    "Design systems",
    "TanStack",
    "AWS",
    "CI/CD",
    "System design",
    "Technical writing",
    "Mentorship",
  ],
  experience: [
    {
      id: "exp-northline",
      company: "Northline",
      title: "Staff Software Engineer",
      location: "San Francisco, CA",
      start: "2022-04",
      end: "Present",
      bullets: [
        "Led the collaborative editor platform serving 1.4M weekly active users; cut p95 load time from 2.8s to 640ms.",
        "Designed the component and token system adopted by 6 product squads, retiring 40% of one-off UI.",
        "Built the real-time presence layer (CRDT + websockets) that unblocked simultaneous editing for enterprise seats.",
        "Mentored 5 engineers to senior; ran the weekly architecture review and incident postmortems.",
      ],
    },
    {
      id: "exp-harbor",
      company: "Harbor",
      title: "Senior Software Engineer",
      location: "New York, NY",
      start: "2019-06",
      end: "2022-03",
      bullets: [
        "Owned the billing and entitlements service processing $48M ARR with 99.99% invoice accuracy.",
        "Rebuilt the customer dashboard in React + TypeScript; NPS of the surface rose 18 points in two quarters.",
        "Introduced contract testing and a staged rollout pipeline that dropped production incidents 35%.",
      ],
    },
    {
      id: "exp-keel",
      company: "Keel Labs",
      title: "Software Engineer",
      location: "Remote",
      start: "2017-01",
      end: "2019-05",
      bullets: [
        "Shipped the first public API and webhook platform used by 200+ integration partners.",
        "Built internal admin tools that cut support ticket handle time by 40%.",
      ],
    },
  ],
  education: [
    {
      id: "edu-cmu",
      school: "Carnegie Mellon University",
      degree: "B.S. Computer Science",
      year: "2016",
      detail: "Human-computer interaction minor",
    },
  ],
  projects: [
    {
      id: "proj-vellum",
      name: "Open Tokens",
      url: "github.com/mayachen/open-tokens",
      bullets: [
        "Open-source design-token compiler used by 3k GitHub stars; transforms Figma variables into CSS, iOS, and Android.",
      ],
    },
    {
      id: "proj-atlas",
      name: "Atlas Query",
      url: "atlasquery.dev",
      bullets: [
        "Read-only SQL notebook for product managers — shareable, permissioned, no warehouse credentials in the browser.",
      ],
    },
  ],
};

const LINEAR_RESUME: TailoredResume = {
  id: "resume-linear",
  createdAt: "2026-09-12T15:20:00.000Z",
  headline: "Staff Software Engineer — collaborative product, craft, and speed",
  summary:
    "Staff engineer who builds the kind of product Linear is known for: fast, considered, and quietly ambitious. Nine years across editor platforms, design systems, and real-time collaboration. I care about the last 10% — the feel of a surface — as much as the system underneath.",
  skills: [
    "TypeScript",
    "React",
    "Design systems",
    "TanStack",
    "Postgres",
    "Node.js",
    "System design",
    "Technical writing",
    "Mentorship",
    "GraphQL",
    "CI/CD",
    "AWS",
  ],
  experience: [
    {
      id: "exp-northline",
      company: "Northline",
      title: "Staff Software Engineer",
      location: "San Francisco, CA",
      start: "2022-04",
      end: "Present",
      bullets: [
        "Led the collaborative editor used by 1.4M WAU; dropped p95 load from 2.8s to 640ms without sacrificing craft.",
        "Created the token and component system now used by 6 squads — the closest analog to a product-quality design system at a mid-stage company.",
        "Shipped real-time presence (CRDT + websockets) that made simultaneous editing feel native, not bolted on.",
        "Set the quality bar in architecture review; mentored 5 engineers to senior.",
      ],
    },
    {
      id: "exp-harbor",
      company: "Harbor",
      title: "Senior Software Engineer",
      location: "New York, NY",
      start: "2019-06",
      end: "2022-03",
      bullets: [
        "Rebuilt the customer dashboard in React + TypeScript; NPS of the surface rose 18 points in two quarters.",
        "Owned billing and entitlements ($48M ARR) with a staged rollout culture that cut incidents 35%.",
      ],
    },
    {
      id: "exp-keel",
      company: "Keel Labs",
      title: "Software Engineer",
      location: "Remote",
      start: "2017-01",
      end: "2019-05",
      bullets: [
        "Shipped the public API and webhook platform used by 200+ partners — small surface, high leverage.",
      ],
    },
  ],
  education: SAMPLE_PROFILE.education,
  projects: SAMPLE_PROFILE.projects,
  matchScore: 86,
  keywordsHit: [
    "TypeScript",
    "React",
    "design systems",
    "collaboration",
    "performance",
    "craft",
  ],
  keywordsMissed: ["Rust", "Electron"],
  changes: [
    "Reframed the summary around product craft and speed.",
    "Led with editor, design-system, and real-time work.",
    "Shortened Harbor/Keel to keep the page tight.",
    "Moved design systems and TanStack up in skills.",
  ],
  coverNote:
    "Linear’s bar for craft is the reason I’m writing. I’ve spent the last four years making an editor feel instant for a million people a week — tokens, presence, and the unglamorous work of making software feel inevitable. I’d like to do that on a product I already use every day.",
};

const NOTION_RESUME: TailoredResume = {
  id: "resume-notion",
  createdAt: "2026-09-08T18:04:00.000Z",
  headline: "Staff Software Engineer — documents, platforms, and multiplayer",
  summary:
    "Staff engineer specializing in document platforms and the systems around them. I led Northline’s collaborative editor (1.4M WAU), including CRDT presence, a cross-squad design system, and the performance work that made it feel local. Previously owned billing infrastructure and partner APIs.",
  skills: [
    "TypeScript",
    "React",
    "Postgres",
    "GraphQL",
    "Node.js",
    "Design systems",
    "System design",
    "AWS",
    "TanStack",
    "Technical writing",
    "Mentorship",
    "CI/CD",
  ],
  experience: [
    {
      id: "exp-northline",
      company: "Northline",
      title: "Staff Software Engineer",
      location: "San Francisco, CA",
      start: "2022-04",
      end: "Present",
      bullets: [
        "Led the document editor platform (1.4M WAU) including block model, multiplayer, and permissioned sharing.",
        "Built CRDT-backed presence so teams could edit the same page without fighting the cursor.",
        "Scaled a token system across 6 squads so new surfaces shipped on-brand without a design bottleneck.",
        "Cut p95 load time from 2.8s to 640ms through code-splitting, query shaping, and edge caching.",
      ],
    },
    {
      id: "exp-harbor",
      company: "Harbor",
      title: "Senior Software Engineer",
      location: "New York, NY",
      start: "2019-06",
      end: "2022-03",
      bullets: [
        "Owned billing and entitlements processing $48M ARR — the unglamorous backbone of a workspace product.",
        "Rebuilt the customer dashboard; NPS of the surface rose 18 points in two quarters.",
      ],
    },
    {
      id: "exp-keel",
      company: "Keel Labs",
      title: "Software Engineer",
      location: "Remote",
      start: "2017-01",
      end: "2019-05",
      bullets: [
        "Launched the public API and webhooks used by 200+ partners to embed our data in their own tools.",
      ],
    },
  ],
  education: SAMPLE_PROFILE.education,
  projects: [
    {
      id: "proj-atlas",
      name: "Atlas Query",
      url: "atlasquery.dev",
      bullets: [
        "SQL notebook for PMs — shareable, permissioned pages over the warehouse, no credentials in the browser.",
      ],
    },
    SAMPLE_PROFILE.projects[0],
  ],
  matchScore: 81,
  keywordsHit: [
    "documents",
    "multiplayer",
    "TypeScript",
    "React",
    "Postgres",
    "platforms",
  ],
  keywordsMissed: ["Block protocol", "SQLite"],
  changes: [
    "Opened on document platforms and multiplayer.",
    "Reordered projects to lead with Atlas Query.",
    "Emphasized permissions, sharing, and block-model language.",
  ],
  coverNote:
    "I’ve been a Notion power user since the wiki days, and the problems you’re hiring for — documents as a platform, multiplayer that disappears, permissions that don’t fight the page — are the ones I’ve been living in at Northline.",
};

export const SAMPLE_RESUMES: Record<string, TailoredResume> = {
  [LINEAR_RESUME.id]: LINEAR_RESUME,
  [NOTION_RESUME.id]: NOTION_RESUME,
};

export const SAMPLE_APPLICATIONS: Application[] = [
  {
    id: "app-linear",
    company: "Linear",
    role: "Senior Product Engineer",
    location: "Remote — North America",
    source: "Company site",
    jobUrl: "https://linear.app/careers",
    jobDescription: `We're hiring a Senior Product Engineer to work on Linear's core product — issues, projects, and the editor. You will ship features end-to-end in TypeScript and React, sweat the interaction details, and raise the quality bar for a tool used by the best product teams in the world.

What we're looking for:
- Deep TypeScript and React
- Taste for product craft: motion, density, keyboard-first
- Experience with design systems and component libraries
- Comfortable with performance work (we care about 16ms frames)
- Written communication that would pass as a Linear update

Nice to have: Rust, Electron, sync engines, prior work on collaborative editors.`,
    status: "interview",
    appliedAt: "2026-09-14T16:00:00.000Z",
    createdAt: "2026-09-12T15:10:00.000Z",
    updatedAt: "2026-09-16T11:30:00.000Z",
    tailoredResumeId: LINEAR_RESUME.id,
    notes: "Recruiter screen 9/16. Hiring manager 9/22. Sent the craft-forward version.",
  },
  {
    id: "app-notion",
    company: "Notion",
    role: "Software Engineer, Editor",
    location: "San Francisco, CA",
    source: "LinkedIn",
    jobUrl: "https://www.notion.so/careers",
    jobDescription: `The Editor team owns the document at the heart of Notion. We're looking for engineers who want to work on block models, multiplayer, permissions, and the performance of very large pages.

Requirements:
- 5+ years TypeScript/React
- Experience with document or productivity platforms
- Familiarity with CRDTs or operational transform a plus
- Postgres, GraphQL, and API design
- Empathy for a product used as a wiki, a tracker, and a database`,
    status: "applied",
    appliedAt: "2026-09-10T19:20:00.000Z",
    createdAt: "2026-09-08T17:50:00.000Z",
    updatedAt: "2026-09-10T19:20:00.000Z",
    tailoredResumeId: NOTION_RESUME.id,
    notes: "Submitted via Greenhouse. Used the editor/multiplayer version.",
  },
  {
    id: "app-vercel",
    company: "Vercel",
    role: "Product Engineer, Dashboard",
    location: "Remote",
    source: "Referral — Priya N.",
    jobUrl: "https://vercel.com/careers",
    jobDescription: `Help us rebuild the Vercel dashboard: projects, deployments, observability, and the workflows teams live in every day. Product engineers here own UI through to the API.

Looking for:
- React, Next.js / TanStack, TypeScript
- Taste for dense, fast admin surfaces
- Comfort with design systems and tokens
- Interest in DX, preview deployments, and developer workflows`,
    status: "draft",
    appliedAt: null,
    createdAt: "2026-09-18T21:00:00.000Z",
    updatedAt: "2026-09-18T21:00:00.000Z",
    tailoredResumeId: null,
    notes: "Priya offered a referral. Tailor against the dashboard JD before sending.",
  },
];
