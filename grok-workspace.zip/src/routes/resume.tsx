import { createFileRoute } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useRef, type ReactNode } from "react";
import { ExportMenu } from "@/components/export-menu";
import { ResumePaper } from "@/components/resume-paper";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useVellum } from "@/lib/store";
import type {
  Application,
  Education,
  Experience,
  MasterResume,
  Project,
  TailoredResume,
  VellumSnapshot,
} from "@/lib/types";
import { uid } from "@/lib/utils";

export const Route = createFileRoute("/resume")({ component: MasterResumePage });

function MasterResumePage() {
  const profile = useVellum((s) => s.profile);
  const setProfile = useVellum((s) => s.setProfile);
  const resetWorkspace = useVellum((s) => s.resetWorkspace);
  const importSnapshot = useVellum((s) => s.importSnapshot);
  const fileRef = useRef<HTMLInputElement>(null);

  function patch(partial: Partial<MasterResume>) {
    setProfile({ ...profile, ...partial });
  }

  function exportWorkspace() {
    const { applications, resumes } = useVellum.getState();
    const blob = new Blob(
      [JSON.stringify({ profile, applications, resumes }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "vellum-workspace.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  function onImport(file: File | undefined) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as Partial<VellumSnapshot>;
        if (!parsed.profile?.fullName) throw new Error("Invalid file");
        importSnapshot({
          profile: parsed.profile,
          applications: Array.isArray(parsed.applications)
            ? (parsed.applications as Application[])
            : [],
          resumes:
            parsed.resumes && typeof parsed.resumes === "object"
              ? (parsed.resumes as Record<string, TailoredResume>)
              : {},
        });
        toast("Workspace imported");
      } catch {
        toast("Could not read that file");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-2">
      <div className="flex flex-col gap-8">
        <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              Source of truth
            </p>
            <h1 className="mt-1 font-display text-3xl tracking-tight">Master resume</h1>
            <p className="mt-2 max-w-md text-sm text-muted-foreground">
              Edit once. Every tailored version starts from here — we never invent facts.
            </p>
          </div>
          <ExportMenu resume={profile} />
        </header>

        <section className="flex flex-col gap-4">
          <Field label="Full name">
            <Input
              value={profile.fullName}
              onChange={(e) => patch({ fullName: e.target.value })}
            />
          </Field>
          <Field label="Headline">
            <Input
              value={profile.headline}
              onChange={(e) => patch({ headline: e.target.value })}
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Email">
              <Input
                value={profile.email}
                onChange={(e) => patch({ email: e.target.value })}
              />
            </Field>
            <Field label="Phone">
              <Input
                value={profile.phone}
                onChange={(e) => patch({ phone: e.target.value })}
              />
            </Field>
            <Field label="Location">
              <Input
                value={profile.location}
                onChange={(e) => patch({ location: e.target.value })}
              />
            </Field>
            <Field label="Website">
              <Input
                value={profile.website}
                onChange={(e) => patch({ website: e.target.value })}
              />
            </Field>
          </div>
          <Field label="Summary">
            <Textarea
              rows={5}
              value={profile.summary}
              onChange={(e) => patch({ summary: e.target.value })}
            />
          </Field>
          <Field label="Skills" hint="Comma separated">
            <Input
              value={profile.skills.join(", ")}
              onChange={(e) =>
                patch({
                  skills: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                })
              }
            />
          </Field>
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl">Experience</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                patch({
                  experience: [
                    {
                      id: uid(),
                      company: "",
                      title: "",
                      location: "",
                      start: "",
                      end: "",
                      bullets: [""],
                    },
                    ...profile.experience,
                  ],
                })
              }
            >
              <Plus />
              Add role
            </Button>
          </div>
          {profile.experience.map((job, index) => (
            <ExperienceEditor
              key={job.id}
              job={job}
              onChange={(next) => {
                const experience = profile.experience.slice();
                experience[index] = next;
                patch({ experience });
              }}
              onRemove={() =>
                patch({
                  experience: profile.experience.filter((e) => e.id !== job.id),
                })
              }
            />
          ))}
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl">Projects</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                patch({
                  projects: [
                    { id: uid(), name: "", url: "", bullets: [""] },
                    ...profile.projects,
                  ],
                })
              }
            >
              <Plus />
              Add project
            </Button>
          </div>
          {profile.projects.map((p, index) => (
            <ProjectEditor
              key={p.id}
              project={p}
              onChange={(next) => {
                const projects = profile.projects.slice();
                projects[index] = next;
                patch({ projects });
              }}
              onRemove={() =>
                patch({
                  projects: profile.projects.filter((x) => x.id !== p.id),
                })
              }
            />
          ))}
        </section>

        <section className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl">Education</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                patch({
                  education: [
                    ...profile.education,
                    { id: uid(), school: "", degree: "", year: "", detail: "" },
                  ],
                })
              }
            >
              <Plus />
              Add
            </Button>
          </div>
          {profile.education.map((e, index) => (
            <EducationEditor
              key={e.id}
              edu={e}
              onChange={(next) => {
                const education = profile.education.slice();
                education[index] = next;
                patch({ education });
              }}
              onRemove={() =>
                patch({
                  education: profile.education.filter((x) => x.id !== e.id),
                })
              }
            />
          ))}
        </section>

        <section className="flex flex-wrap gap-2 border-t border-border pt-6">
          <Button variant="outline" size="sm" onClick={exportWorkspace}>
            Download workspace
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fileRef.current?.click()}
          >
            Import workspace
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => onImport(e.target.files?.[0])}
          />
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              resetWorkspace();
              toast("Sample workspace restored");
            }}
          >
            Restore sample
          </Button>
        </section>
      </div>

      <div className="no-print hidden lg:block">
        <div className="sticky top-8">
          <p className="mb-3 text-xs font-medium tracking-widest text-muted-foreground uppercase">
            Preview
          </p>
          <ResumePaper resume={profile} />
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between">
        <Label>{label}</Label>
        {hint ? <span className="text-xs text-muted-foreground">{hint}</span> : null}
      </div>
      {children}
    </div>
  );
}

function ExperienceEditor({
  job,
  onChange,
  onRemove,
}: {
  job: Experience;
  onChange: (job: Experience) => void;
  onRemove: () => void;
}) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-border">
      <div className="mb-3 flex justify-end">
        <Button variant="ghost" size="icon-sm" onClick={onRemove} aria-label="Remove role">
          <Trash2 />
        </Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Input
          placeholder="Title"
          value={job.title}
          onChange={(e) => onChange({ ...job, title: e.target.value })}
        />
        <Input
          placeholder="Company"
          value={job.company}
          onChange={(e) => onChange({ ...job, company: e.target.value })}
        />
        <Input
          placeholder="Location"
          value={job.location}
          onChange={(e) => onChange({ ...job, location: e.target.value })}
        />
        <div className="grid grid-cols-2 gap-2">
          <Input
            placeholder="Start (YYYY-MM)"
            value={job.start}
            onChange={(e) => onChange({ ...job, start: e.target.value })}
          />
          <Input
            placeholder="End or Present"
            value={job.end}
            onChange={(e) => onChange({ ...job, end: e.target.value })}
          />
        </div>
      </div>
      <Textarea
        className="mt-3"
        rows={5}
        placeholder="One achievement per line"
        value={job.bullets.join("\n")}
        onChange={(e) =>
          onChange({ ...job, bullets: e.target.value.split("\n") })
        }
      />
    </div>
  );
}

function ProjectEditor({
  project,
  onChange,
  onRemove,
}: {
  project: Project;
  onChange: (p: Project) => void;
  onRemove: () => void;
}) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-border">
      <div className="mb-3 flex justify-end">
        <Button variant="ghost" size="icon-sm" onClick={onRemove} aria-label="Remove project">
          <Trash2 />
        </Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Input
          placeholder="Name"
          value={project.name}
          onChange={(e) => onChange({ ...project, name: e.target.value })}
        />
        <Input
          placeholder="URL"
          value={project.url}
          onChange={(e) => onChange({ ...project, url: e.target.value })}
        />
      </div>
      <Textarea
        className="mt-3"
        rows={3}
        placeholder="One line per bullet"
        value={project.bullets.join("\n")}
        onChange={(e) =>
          onChange({ ...project, bullets: e.target.value.split("\n") })
        }
      />
    </div>
  );
}

function EducationEditor({
  edu,
  onChange,
  onRemove,
}: {
  edu: Education;
  onChange: (e: Education) => void;
  onRemove: () => void;
}) {
  return (
    <div className="grid gap-3 rounded-xl bg-card p-4 shadow-border sm:grid-cols-12">
      <div className="grid gap-3 sm:col-span-11 sm:grid-cols-2">
        <Input
          placeholder="Degree"
          value={edu.degree}
          onChange={(e) => onChange({ ...edu, degree: e.target.value })}
        />
        <Input
          placeholder="School"
          value={edu.school}
          onChange={(e) => onChange({ ...edu, school: e.target.value })}
        />
        <Input
          placeholder="Year"
          value={edu.year}
          onChange={(e) => onChange({ ...edu, year: e.target.value })}
        />
        <Input
          placeholder="Detail"
          value={edu.detail}
          onChange={(e) => onChange({ ...edu, detail: e.target.value })}
        />
      </div>
      <Button
        variant="ghost"
        size="icon-sm"
        className="sm:col-span-1"
        onClick={onRemove}
        aria-label="Remove education"
      >
        <Trash2 />
      </Button>
    </div>
  );
}
