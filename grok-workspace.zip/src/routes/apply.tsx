import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ListFilter, Loader2, PenLine } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { ExportMenu } from "@/components/export-menu";
import { ResumePaper } from "@/components/resume-paper";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { quickTailor } from "@/lib/quick-match";
import { composeResume } from "@/lib/resume-text";
import { createApplicationDraft, useVellum } from "@/lib/store";
import { tailorResume } from "@/lib/tailor";
import type { TailoredResume } from "@/lib/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/apply")({ component: ApplyPage });

function ApplyPage() {
  const navigate = useNavigate();
  const profile = useVellum((s) => s.profile);
  const upsertApplication = useVellum((s) => s.upsertApplication);
  const saveTailored = useVellum((s) => s.saveTailored);

  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [location, setLocation] = useState("");
  const [source, setSource] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [tailored, setTailored] = useState<TailoredResume | null>(null);
  const [busy, setBusy] = useState<"ai" | "quick" | "save" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const preview = composeResume(profile, tailored);

  async function runAi() {
    if (!jobDescription.trim()) {
      toast("Paste a job description first");
      return;
    }
    setBusy("ai");
    setError(null);
    try {
      const result = await tailorResume({
        data: {
          profile,
          company,
          role,
          jobDescription,
        },
      });
      if (!result.ok) {
        setError(result.error);
        toast(result.error);
        return;
      }
      setTailored(result.resume);
      toast("Tailored resume ready");
    } catch {
      setError("Something went wrong talking to the tailor.");
      toast("Could not tailor this resume");
    } finally {
      setBusy(null);
    }
  }

  function runQuick() {
    if (!jobDescription.trim()) {
      toast("Paste a job description first");
      return;
    }
    setBusy("quick");
    setError(null);
    const next = quickTailor(profile, jobDescription);
    setTailored(next);
    setBusy(null);
    toast("Skills reordered from the job description");
  }

  function save(markApplied: boolean) {
    if (!company.trim() || !role.trim()) {
      toast("Add a company and role before saving");
      return;
    }
    setBusy("save");
    const app = createApplicationDraft({
      company: company.trim(),
      role: role.trim(),
      location: location.trim(),
      source: source.trim(),
      jobUrl: jobUrl.trim(),
      jobDescription,
      notes,
      status: markApplied ? "applied" : "draft",
      appliedAt: markApplied ? new Date().toISOString() : null,
    });
    upsertApplication(app);
    if (tailored) saveTailored(app.id, { ...tailored, id: tailored.id });
    setBusy(null);
    toast(markApplied ? "Marked as applied" : "Saved to the board");
    void navigate({ to: "/applications/$id", params: { id: app.id } });
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-12">
      <div className="flex flex-col gap-6 lg:col-span-4">
        <header>
          <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
            New role
          </p>
          <h1 className="mt-1 font-display text-3xl tracking-tight">
            Tailor a resume
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Paste the job. Vellum rewrites emphasis — never the facts — and files the copy with this application.
          </p>
        </header>

        <div className="grid gap-3">
          <Field label="Company">
            <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Linear" />
          </Field>
          <Field label="Role">
            <Input value={role} onChange={(e) => setRole(e.target.value)} placeholder="Senior Product Engineer" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Location">
              <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Remote" />
            </Field>
            <Field label="Source">
              <Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="Referral, site…" />
            </Field>
          </div>
          <Field label="Posting URL">
            <Input value={jobUrl} onChange={(e) => setJobUrl(e.target.value)} placeholder="https://" />
          </Field>
          <Field label="Job description">
            <Textarea
              rows={12}
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the full posting…"
              className="min-h-48"
            />
          </Field>
          <Field label="Private notes">
            <Textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Recruiter name, referral, deadline…"
            />
          </Field>
        </div>

        <div className="flex flex-col gap-2">
          <Button onClick={() => void runAi()} disabled={busy !== null}>
            {busy === "ai" ? <Loader2 className="animate-spin" /> : <PenLine />}
            Tailor with AI
          </Button>
          <Button variant="outline" onClick={runQuick} disabled={busy !== null}>
            <ListFilter />
            Quick match (no rewrite)
          </Button>
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>
      </div>

      <div className="flex flex-col gap-4 lg:col-span-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              {tailored ? "Tailored copy" : "Master (not yet tailored)"}
            </p>
            {tailored?.matchScore != null ? (
              <p className="mt-1 text-sm text-muted-foreground">
                Match score{" "}
                <span className="font-medium tabular-nums text-foreground">
                  {tailored.matchScore}
                </span>
              </p>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-2">
            <ExportMenu resume={preview} />
            <Button
              variant="secondary"
              onClick={() => save(false)}
              disabled={busy !== null}
            >
              Save draft
            </Button>
            <Button onClick={() => save(true)} disabled={busy !== null}>
              Save & mark applied
            </Button>
          </div>
        </div>

        {tailored ? <MatchPanel tailored={tailored} /> : null}

        <ResumePaper resume={preview} />
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function MatchPanel({ tailored }: { tailored: TailoredResume }) {
  return (
    <div className="rounded-xl bg-card p-5 shadow-border">
      {tailored.changes.length > 0 ? (
        <div>
          <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
            What changed
          </p>
          <ul className="mt-2 flex flex-col gap-1.5">
            {tailored.changes.map((c) => (
              <li key={c} className="text-sm leading-relaxed">
                {c}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className={cn("grid gap-4", tailored.changes.length > 0 && "mt-4 sm:grid-cols-2")}>
        {tailored.keywordsHit.length > 0 ? (
          <div>
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              Hits
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {tailored.keywordsHit.map((k) => (
                <span
                  key={k}
                  className="rounded-full bg-success/12 px-2.5 py-0.5 text-xs text-success"
                >
                  {k}
                </span>
              ))}
            </div>
          </div>
        ) : null}
        {tailored.keywordsMissed.length > 0 ? (
          <div>
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              Not claimed
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {tailored.keywordsMissed.map((k) => (
                <span
                  key={k}
                  className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-muted-foreground"
                >
                  {k}
                </span>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {tailored.coverNote ? (
        <div className="mt-4 border-t border-border pt-4">
          <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
            Cover note
          </p>
          <p className="mt-2 text-sm leading-relaxed">{tailored.coverNote}</p>
        </div>
      ) : null}
    </div>
  );
}
