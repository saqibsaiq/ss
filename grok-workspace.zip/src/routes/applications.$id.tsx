import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Loader2, PenLine, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ExportMenu } from "@/components/export-menu";
import { ResumePaper } from "@/components/resume-paper";
import { StatusSelect } from "@/components/status-select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { composeResume } from "@/lib/resume-text";
import { useVellum } from "@/lib/store";
import { tailorResume } from "@/lib/tailor";
import { formatDate } from "@/lib/utils";
import type { TailoredResume } from "@/lib/types";

export const Route = createFileRoute("/applications/$id")({
  component: ApplicationDetail,
});

function ApplicationDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const application = useVellum((s) => s.applications.find((a) => a.id === id));
  const profile = useVellum((s) => s.profile);
  const resumes = useVellum((s) => s.resumes);
  const upsertApplication = useVellum((s) => s.upsertApplication);
  const setStatus = useVellum((s) => s.setStatus);
  const saveTailored = useVellum((s) => s.saveTailored);
  const deleteApplication = useVellum((s) => s.deleteApplication);
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<"sent" | "master">("sent");

  const tailored: TailoredResume | null = application?.tailoredResumeId
    ? (resumes[application.tailoredResumeId] ?? null)
    : null;

  const preview = useMemo(
    () => composeResume(profile, view === "master" ? null : tailored),
    [profile, tailored, view],
  );

  if (!application) {
    return (
      <div className="mx-auto max-w-lg py-20 text-center">
        <p className="font-display text-2xl">This application is gone</p>
        <p className="mt-2 text-sm text-muted-foreground">
          It may have been deleted from this browser’s ledger.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          Back to the board
        </Link>
      </div>
    );
  }

  async function retailor() {
    if (!application) return;
    setBusy(true);
    try {
      const result = await tailorResume({
        data: {
          profile,
          company: application.company,
          role: application.role,
          jobDescription: application.jobDescription,
        },
      });
      if (!result.ok) {
        toast(result.error);
        return;
      }
      saveTailored(application.id, result.resume);
      setView("sent");
      toast("New tailored copy filed");
    } catch {
      toast("Could not tailor this resume");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-12">
      <div className="flex flex-col gap-6 lg:col-span-4">
        <div>
          <Link
            to="/"
            className="inline-flex h-9 items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" />
            Board
          </Link>
          <p className="mt-4 text-xs font-medium tracking-widest text-muted-foreground uppercase">
            Application
          </p>
          <h1 className="mt-1 font-display text-3xl tracking-tight">
            {application.company}
          </h1>
          <p className="mt-1 text-muted-foreground">{application.role}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <StatusSelect
            value={application.status}
            onChange={(status) => setStatus(application.id, status)}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              deleteApplication(application.id);
              toast("Removed from the ledger");
              void navigate({ to: "/" });
            }}
          >
            <Trash2 />
            Delete
          </Button>
        </div>

        <dl className="grid grid-cols-2 gap-3 text-sm">
          <Meta label="Opened" value={formatDate(application.createdAt)} />
          <Meta label="Applied" value={formatDate(application.appliedAt)} />
          <Meta label="Location" value={application.location || "—"} />
          <Meta label="Source" value={application.source || "—"} />
        </dl>

        {application.jobUrl ? (
          <a
            href={application.jobUrl}
            target="_blank"
            rel="noreferrer"
            className="text-sm underline-offset-4 hover:underline"
          >
            Open posting
          </a>
        ) : null}

        <div className="flex flex-col gap-1.5">
          <Label>Notes</Label>
          <Textarea
            rows={3}
            value={application.notes}
            onChange={(e) =>
              upsertApplication({ ...application, notes: e.target.value })
            }
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <Label>Job description</Label>
          <Textarea
            rows={10}
            value={application.jobDescription}
            onChange={(e) =>
              upsertApplication({
                ...application,
                jobDescription: e.target.value,
              })
            }
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <Label>Company</Label>
          <Input
            value={application.company}
            onChange={(e) =>
              upsertApplication({ ...application, company: e.target.value })
            }
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label>Role</Label>
          <Input
            value={application.role}
            onChange={(e) =>
              upsertApplication({ ...application, role: e.target.value })
            }
          />
        </div>
      </div>

      <div className="flex flex-col gap-4 lg:col-span-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
              Resume on file
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {tailored
                ? `Custom version filed ${formatDate(tailored.createdAt)}`
                : "This role still uses the master resume"}
              {tailored?.matchScore != null
                ? ` · match ${tailored.matchScore}`
                : ""}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {tailored ? (
              <Select
                value={view}
                onValueChange={(v) => setView(v as "sent" | "master")}
              >
                <SelectTrigger className="h-10 w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sent">Version sent</SelectItem>
                  <SelectItem value="master">Master resume</SelectItem>
                </SelectContent>
              </Select>
            ) : null}
            <ExportMenu resume={preview} />
            <Button onClick={() => void retailor()} disabled={busy}>
              {busy ? <Loader2 className="animate-spin" /> : <PenLine />}
              {tailored ? "Re-tailor" : "Tailor now"}
            </Button>
          </div>
        </div>

        {tailored && view === "sent" ? (
          <div className="rounded-xl bg-card p-5 shadow-border">
            {tailored.changes.length > 0 ? (
              <ul className="flex flex-col gap-1.5">
                {tailored.changes.map((c) => (
                  <li key={c} className="text-sm leading-relaxed">
                    {c}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">
                Filed without change notes.
              </p>
            )}
            {tailored.coverNote ? (
              <p className="mt-4 border-t border-border pt-4 text-sm leading-relaxed">
                {tailored.coverNote}
              </p>
            ) : null}
          </div>
        ) : null}

        <ResumePaper resume={preview} />
      </div>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs tracking-wide text-muted-foreground uppercase">{label}</dt>
      <dd className="mt-0.5">{value}</dd>
    </div>
  );
}
