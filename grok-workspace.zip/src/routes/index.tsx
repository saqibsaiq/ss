import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Briefcase, FileCheck2, MessagesSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { StatusBadge } from "@/components/status-select";
import { useVellum } from "@/lib/store";
import { PIPELINE_COLUMNS, type Application } from "@/lib/types";
import { formatDate } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Board });

function Board() {
  const applications = useVellum((s) => s.applications);
  const resumes = useVellum((s) => s.resumes);
  const profile = useVellum((s) => s.profile);
  const firstName = profile.fullName.trim().split(/\s+/)[0] || "Your";

  const applied = applications.filter((a) => a.status !== "draft").length;
  const interviews = applications.filter((a) => a.status === "interview" || a.status === "offer").length;
  const tailored = applications.filter((a) => a.tailoredResumeId).length;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium tracking-widest text-muted-foreground uppercase">
            Application board
          </p>
          <h1 className="mt-1 font-display text-3xl tracking-tight sm:text-4xl">
            {firstName}&rsquo;s ledger
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Every role gets its own resume. Open a card to see the exact version that went out.
          </p>
        </div>
        <Link
          to="/apply"
          className="inline-flex h-11 items-center justify-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground shadow-border transition-[opacity,transform] duration-150 hover:opacity-90 active:scale-[0.96]"
        >
          Tailor for a new role
        </Link>
      </header>

      <section className="grid gap-3 sm:grid-cols-3">
        <Stat icon={Briefcase} label="Roles in play" value={applied} hint="Anything past draft" />
        <Stat icon={MessagesSquare} label="Conversations" value={interviews} hint="Interview or offer" />
        <Stat icon={FileCheck2} label="Tailored copies" value={tailored} hint="Versions on file" />
      </section>

      <section className="hidden gap-3 lg:grid lg:grid-cols-4">
        {PIPELINE_COLUMNS.map((col) => {
          const items = applications.filter((a) => col.statuses.includes(a.status));
          return (
            <div key={col.key} className="flex min-h-80 flex-col rounded-xl bg-studio/70 p-3">
              <div className="mb-3 flex items-baseline justify-between px-1">
                <h2 className="text-sm font-medium">{col.label}</h2>
                <span className="text-xs tabular-nums text-muted-foreground">{items.length}</span>
              </div>
              <div className="flex flex-1 flex-col gap-2">
                {items.length === 0 ? (
                  <p className="px-1 text-xs text-muted-foreground">Nothing here yet.</p>
                ) : (
                  items.map((app) => (
                    <ApplicationCard
                      key={app.id}
                      app={app}
                      tailored={Boolean(app.tailoredResumeId && resumes[app.tailoredResumeId])}
                    />
                  ))
                )}
              </div>
            </div>
          );
        })}
      </section>

      <section className="flex flex-col gap-2 lg:hidden">
        {applications.length === 0 ? (
          <EmptyBoard />
        ) : (
          applications.map((app) => (
            <ApplicationCard
              key={app.id}
              app={app}
              tailored={Boolean(app.tailoredResumeId && resumes[app.tailoredResumeId])}
            />
          ))
        )}
      </section>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: typeof Briefcase;
  label: string;
  value: number;
  hint: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-start gap-3 p-5">
        <span className="flex size-10 items-center justify-center rounded-lg bg-secondary text-foreground">
          <Icon className="size-4" />
        </span>
        <div>
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{label}</p>
          <p className="mt-1 font-display text-3xl tabular-nums leading-none">{value}</p>
          <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function ApplicationCard({ app, tailored }: { app: Application; tailored: boolean }) {
  return (
    <Link
      to="/applications/$id"
      params={{ id: app.id }}
      className="block rounded-lg bg-card p-4 shadow-border transition-[box-shadow,transform] duration-150 hover:shadow-border-hover"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate font-medium">{app.company || "Untitled company"}</p>
          <p className="truncate text-sm text-muted-foreground">{app.role || "Untitled role"}</p>
        </div>
        <ArrowUpRight className="size-4 shrink-0 text-muted-foreground" />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <StatusBadge status={app.status} />
        <span className="text-xs text-muted-foreground">
          {tailored ? "Custom resume on file" : "Master resume"}
        </span>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {app.appliedAt ? `Applied ${formatDate(app.appliedAt)}` : `Opened ${formatDate(app.createdAt)}`}
      </p>
    </Link>
  );
}

function EmptyBoard() {
  return (
    <div className="rounded-xl bg-card px-6 py-12 text-center shadow-border">
      <p className="font-display text-xl">No applications yet</p>
      <p className="mt-2 text-sm text-muted-foreground">
        Paste a job description and Vellum will cut a resume for that role.
      </p>
      <Link
        to="/apply"
        className="mt-5 inline-flex h-11 items-center rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground"
      >
        Start the first one
      </Link>
    </div>
  );
}
